####################################################
#               WebApp Python con Flask            #
#                                                  #
#   Comandi per il venv:                           #
#       python -m venv .venv                       #
#       .venv\Scripts\activate                     #
#                                                  #
#   Comandi per installare le librerie:            #
#       pip install flask                          #
#       pip install flask-session                  #
#       pip install mysql-connector-python         #
#       pip install redis                          #
#                                                  #
#   Comando per lanciare l'app:                    #
#       cd .\Python-Flask-WebApp\                  #
#       python server.py                           #
#       Digitare 'test' come password SSL          #
#    avviare redis:                                #
#       cd C:\Programmi\Redis                      #
#       redis-server.exe                           #
#    tenere aperto in un altro terminale redis     #
#                                                  #
#   Installare Redis su Windows:                   #
#   https://github.com/zkteco-home/redis-windows   #
#                                                  #
#   N.B. Avviare XAMPP con solo MySQL e Redis      #
#                                                  #
####################################################

# Importo le librerie
import hashlib
from flask import Flask
from flask import Flask, render_template, request, redirect, url_for
from flask_session import Session
from flask_talisman import Talisman
import mysql.connector
import redis
import os
import datetime
from dotenv import load_dotenv

load_dotenv()

##############################################
# FUNZIONI DI INZIALIZZAZIONE:
# Setup
app = Flask(__name__)
app.config["SESSION_PERMANENT"] = False     # Sessions scade quando si chiude il browser
app.config["SESSION_TYPE"] = "filesystem"     # Salva la sessione in un file in locale
Session(app)

#questo serve per renderlo https e non https
Talisman(app, content_security_policy=None, force_https=True)

#questa fa connettere il db in base a cosa gli viene passato dal .env
def get_db(with_db=True):
    db_config = {
        "user": os.getenv("DB_USER"),
        "password": os.getenv("DB_PASSWORD"),
        "host": os.getenv("DB_HOST"),
        "autocommit": True
    }

    if with_db:
        db_config["database"] = os.getenv("DB_NAME")

    return mysql.connector.connect(**db_config)

#SETUP DATI BASE DI REDIS
def setup_redis(cnx_redis):
    cnx_redis.set("accesso_eseguito", "")
    cnx_redis.set("msg", "")
    
#se non ha il db in locale lo inizializza
def inizializza_progetto(db_name):
    cnx_sql = None
    cursor = None
    try:
        cnx_sql = get_db(with_db=False)
        cursor = cnx_sql.cursor(dictionary=True)
        
        #Verifica/Creazione Database
        cursor.execute("SHOW DATABASES")
        #recupero tutti i dati dal cursore (che restituisce una lista di dizionari)
        risultati_db = cursor.fetchall()
        databases = []

        #Ciclo per estrarre solo la colonna 'Database'
        for riga in risultati_db:
            nome_db = riga['Database']
            databases.append(nome_db)

        if db_name not in databases:
            print(f">>> Creazione database '{db_name}'...")
            cursor.execute(f"CREATE DATABASE {db_name}")
        
        # Selezioniamo il database per tutte le operazioni successive
        cursor.execute(f"USE {db_name}")

        # LISTA QUERY CREAZIONE (Ordinate per dipendenza)
        tabelle = [
            # Ruoli
            """CREATE TABLE IF NOT EXISTS ruoli (
                id_ruolo INT PRIMARY KEY AUTO_INCREMENT,
                nome_ruolo VARCHAR(50) NOT NULL,
                codice_attivazione VARCHAR(50)
            )""",
            # Utenti
            """CREATE TABLE IF NOT EXISTS utenti (
                id_utente INT PRIMARY KEY AUTO_INCREMENT,
                nome_utente VARCHAR(50) NOT NULL,
                cognome_utente VARCHAR(50) NOT NULL,
                cf CHAR(16) UNIQUE,
                email VARCHAR(100) UNIQUE,
                password VARCHAR(255),
                data_nascita DATE,
                stato_account VARCHAR(20),
                ultimo_accesso DATE,
                data_iscrizione DATE,
                fk_ruolo INT,
                FOREIGN KEY (fk_ruolo) REFERENCES ruoli(id_ruolo) ON DELETE SET NULL
            )""",
            # Pagamenti
            """CREATE TABLE IF NOT EXISTS pagamenti (
                id_pagamento INT PRIMARY KEY AUTO_INCREMENT,
                metodo_pagamento VARCHAR(50),
                totale_pagamento INT,
                stato_pagamento VARCHAR(20)
            )""",
            # Prenotazioni
            """CREATE TABLE IF NOT EXISTS prenotazioni (
                id_prenotazione INT PRIMARY KEY AUTO_INCREMENT,
                tipo_prenotazione VARCHAR(50),
                costo_prenotazione INT,
                data_prenotazione DATE,
                orario TIME, 
                fk_utente INT,
                fk_pagamento INT,
                FOREIGN KEY (fk_utente) REFERENCES utenti(id_utente) ON DELETE CASCADE,
                FOREIGN KEY (fk_pagamento) REFERENCES pagamenti(id_pagamento) ON DELETE SET NULL
            )""",
            # Patenti
            """CREATE TABLE IF NOT EXISTS patenti (
                id_patente INT PRIMARY KEY AUTO_INCREMENT,
                tipologia_patente VARCHAR(10),
                descrizione VARCHAR(255),
                eta_minima INT,
                costo INT
            )""",
            # Ute_Pat
            """CREATE TABLE IF NOT EXISTS ute_pat (
                id_ute_pat INT PRIMARY KEY AUTO_INCREMENT,
                data_conseguimento DATE,
                data_scadenza DATE,
                fk_utente INT,
                fk_patente INT,
                FOREIGN KEY (fk_utente) REFERENCES utenti(id_utente) ON DELETE CASCADE,
                FOREIGN KEY (fk_patente) REFERENCES patenti(id_patente) ON DELETE CASCADE
            )""",
            # Capitoli
            """CREATE TABLE IF NOT EXISTS capitoli (
                id_capitolo INT PRIMARY KEY AUTO_INCREMENT,
                nome_capitolo VARCHAR(100) NOT NULL,
                difficolta VARCHAR(20),
                fk_patente INT,
                FOREIGN KEY (fk_patente) REFERENCES patenti(id_patente) ON DELETE CASCADE
            )""",
            # Quiz
            """CREATE TABLE IF NOT EXISTS quiz (
                id_quiz INT PRIMARY KEY AUTO_INCREMENT,
                difficolta VARCHAR(20),
                link_quiz VARCHAR(255),
                fk_capitolo INT,
                FOREIGN KEY (fk_capitolo) REFERENCES capitoli(id_capitolo) ON DELETE CASCADE
            )""",
            # Lezioni
            """CREATE TABLE IF NOT EXISTS lezioni (
                id_lezione INT PRIMARY KEY AUTO_INCREMENT,
                durata_lezione INT,
                data_lezione DATE,
                aula_meet VARCHAR(100),
                orario TIME,
                fk_capitolo INT,
                FOREIGN KEY (fk_capitolo) REFERENCES capitoli(id_capitolo) ON DELETE CASCADE
            )"""
        ]

        #faccio exectue di qutte le query
        for q in tabelle:
            cursor.execute(q)

        #Inserimento dei dati
        cursor.execute("SELECT COUNT(*) as tot FROM ruoli")
        if cursor.fetchone()['tot'] == 0:
            # RUOLI
            cursor.execute("INSERT INTO ruoli (nome_ruolo, codice_attivazione) VALUES ('Studente', '123'), ('Istruttore', '456')")
            
        #utenti 
        cursor.execute("SELECT COUNT(*) AS tot FROM utenti")
        if cursor.fetchone()['tot']==0:
            sql_utenti = "INSERT INTO utenti (nome_utente, cognome_utente, cf, email,password,data_nascita,stato_account,ultimo_accesso,data_iscrizione,fk_ruolo) VALUES (%s, %s, %s, %s,%s, %s, %s, %s,%s,%s)"
            val_utenti = [
                ("mario","rossi","RSSMRA80A01B898W","mario.rossi@gmail.com","b133a0c0e9bee3be20163d2ad31d6248db292aa6dcb1ee087a2aa50e0fc75ae2","1980-01-01","2026-04-10","2026-04-10",2),
                ("giacomo","bianchi","BNCGCM05H06B898X","giacomo.bianchi@gmail.com","b133a0c0e9bee3be20163d2ad31d6248db292aa6dcb1ee087a2aa50e0fc75ae2","2005-06-06","2026-04-10","2026-04-10",1)
            ]
            cursor.executemany(sql_utenti, val_utenti)
            
        cursor.execute("SELECT COUNT(*) as tot FROM patenti")
        if cursor.fetchone()['tot'] == 0:
            # PATENTI
            sql_patenti = "INSERT INTO patenti (tipologia_patente, descrizione, eta_minima, costo) VALUES (%s, %s, %s, %s)"
            val_patenti = [
                ('AM','Ciclomotori a 2 o 3 ruote e quadricicli leggeri',14,400),
                ('A1','Motocicli fino a 125 cc e 11 kW, tricicli fino a 15 kW',16,600),
                ('A2','Motocicli fino a 35 kW',18,700),
                ('A','Motocicli senza limiti di potenza',24,800),
                ('B1','Quadricicli non leggeri',16,700),
                ('B','Autoveicoli fino a 3,5 t e massimo 9 posti',18,900),
                ('BE','Autoveicoli cat. B con rimorchio oltre 750 kg',18,600),
                ('C1','Autocarri tra 3,5 t e 7,5 t',18,1250),
                ('C1E','Autocarri cat. C1 con rimorchio oltre 750 kg',18,1300),
                ('C','Autocarri oltre 3,5 t',21,1200),
                ('CE','Autocarri cat. C con rimorchio oltre 750 kg',21,1350),
                ('D1','Autobus fino a 16 passeggeri oltre al conducente',21,1400),
                ('D1E','Autobus cat. D1 con rimorchio oltre 750 kg',21,1350),
                ('D','Autobus senza limite di passeggeri',24,1300),
                ('DE','Autobus cat. D con rimorchio oltre 750 kg',24,1370),
                ('KA','Macchine agricole',16,1200),
                ('KB','Certificato abilitazione professionale per taxi e NCC',21,1200),
                ('CQC Person','Carta di Qualificazione del Conducente per trasporto persone',21,1500),
                ('CQC Merci','Carta di Qualificazione del Conducente per trasporto merci',21,1500)
            ]
            cursor.executemany(sql_patenti, val_patenti)
        
        cursor.execute("SELECT COUNT(*) as tot FROM capitoli")
        if cursor.fetchone()['tot'] == 0:
            sql_cap = "INSERT INTO capitoli (nome_capitolo, difficolta, fk_patente) VALUES (%s, %s, %s)"
            val_cap = [
                ('Segnali di pericolo', 1, 6), ('Segnali di pericolo', 1, 4), ('Segnali di pericolo', 1, 3),
                ('Segnali di pericolo', 1, 2), ('Segnali di pericolo', 1, 1), ('Segnali di divieto', 1, 6),
                ('Segnali di divieto', 1, 4), ('Segnali di divieto', 1, 3), ('Segnali di divieto', 1, 2),
                ('Segnali di divieto', 1, 1), ('Segnali di obbligo', 1, 6), ('Segnali di obbligo', 1, 4),
                ('Segnali di obbligo', 1, 3), ('Segnali di obbligo', 1, 2), ('Segnali di obbligo', 1, 1),
                ('Segnali di precedenza', 2, 6), ('Segnali di precedenza', 2, 4), ('Segnali di precedenza', 2, 3),
                ('Segnali di precedenza', 2, 2), ('Segnali di precedenza', 2, 1), ('Segnaletica orizzontale', 2, 6),
                ('Segnaletica orizzontale', 2, 4), ('Segnaletica orizzontale', 2, 3), ('Segnaletica orizzontale', 2, 2),
                ('Segnaletica orizzontale', 2, 1), ('Segnalazioni del traffico', 2, 6), ('Segnalazioni del traffico', 2, 4),
                ('Segnalazioni del traffico', 2, 3), ('Segnalazioni del traffico', 2, 2), ('Segnalazioni del traffico', 2, 1),
                ('Limiti di velocità', 1, 6), ('Limiti di velocità', 1, 4), ('Limiti di velocità', 1, 3), ('Limiti di velocità', 1, 2),
                ('Limiti di velocità', 1, 1), ('Distanza di sicurezza', 2, 6), ('Distanza di sicurezza', 2, 4), ('Distanza di sicurezza', 2, 3),
                ('Distanza di sicurezza', 2, 2), ('Distanza di sicurezza', 2, 1), ('Norme sulla circolazione', 2, 6), ('Norme sulla circolazione', 2, 4),
                ('Norme sulla circolazione', 2, 3), ('Norme sulla circolazione', 2, 2), ('Norme sulla circolazione', 2, 1),
                ('Precedenze', 3, 6), ('Precedenze', 3, 4), ('Precedenze', 3, 3), ('Precedenze', 3, 2), ('Precedenze', 3, 1),
                ('Fermata, sosta e arresto', 2, 6), ('Fermata, sosta e arresto', 2, 4), ('Fermata, sosta e arresto', 2, 3),
                ('Fermata, sosta e arresto', 2, 2), ('Fermata, sosta e arresto', 2, 1), ('Sorpasso', 3, 6), ('Sorpasso', 3, 4),
                ('Sorpasso', 3, 3), ('Sorpasso', 3, 2), ('Sorpasso', 3, 1), ('Patenti, documenti e assicurazione', 2, 6),
                ('Patenti, documenti e assicurazione', 2, 4), ('Patenti, documenti e assicurazione', 2, 3), ('Patenti, documenti e assicurazione', 2, 2),
                ('Patenti, documenti e assicurazione', 2, 1), ('Incidenti stradali e primo soccorso', 3, 6), ('Incidenti stradali e primo soccorso', 3, 4),
                ('Incidenti stradali e primo soccorso', 3, 3), ('Incidenti stradali e primo soccorso', 3, 2), ('Incidenti stradali e primo soccorso', 3, 1),
                ('Alcol, droga e farmaci', 3, 6), ('Alcol, droga e farmaci', 3, 4), ('Alcol, droga e farmaci', 3, 3), ('Alcol, droga e farmaci', 3, 2),
                ('Alcol, droga e farmaci', 3, 1), ('Elementi del veicolo e sicurezza', 3, 6), ('Elementi del veicolo e sicurezza', 3, 4),
                ('Elementi del veicolo e sicurezza', 3, 3), ('Elementi del veicolo e sicurezza', 3, 2), ('Elementi del veicolo e sicurezza', 3, 1),
                ('Manutenzione e uso del veicolo', 3, 6), ('Manutenzione e uso del veicolo', 3, 4), ('Manutenzione e uso del veicolo', 3, 3),
                ('Manutenzione e uso del veicolo', 3, 2), ('Manutenzione e uso del veicolo', 3, 1), ('Pneumatici e freni', 4, 6),
                ('Pneumatici e freni', 4, 4), ('Pneumatici e freni', 4, 3), ('Pneumatici e freni', 4, 2), ('Pneumatici e freni', 4, 1),
                ('Sicurezza attiva e passiva', 3, 6), ('Sicurezza attiva e passiva', 3, 4), ('Sicurezza attiva e passiva', 3, 3),
                ('Sicurezza attiva e passiva', 3, 2), ('Sicurezza attiva e passiva', 3, 1), ('Comportamento verso i pedoni', 2, 6),
                ('Comportamento verso i pedoni', 2, 4), ('Comportamento verso i pedoni', 2, 3), ('Comportamento verso i pedoni', 2, 2),
                ('Comportamento verso i pedoni', 2, 1), ('Rispetto dell’ambiente', 2, 6), ('Rispetto dell’ambiente', 2, 4),
                ('Rispetto dell’ambiente', 2, 3), ('Rispetto dell’ambiente', 2, 2), ('Rispetto dell’ambiente', 2, 1),
                ('Uso delle luci', 2, 6), ('Uso delle luci', 2, 4), ('Uso delle luci', 2, 3), ('Uso delle luci', 2, 2),
                ('Uso delle luci', 2, 1), ('Traino e rimorchio', 4, 6), ('Traino e rimorchio', 4, 4), ('Traino e rimorchio', 4, 3),
                ('Traino e rimorchio', 4, 2), ('Traino e rimorchio', 4, 1), ('Pannelli integrativi', 3, 6), ('Pannelli integrativi', 3, 4),
                ('Pannelli integrativi', 3, 3), ('Pannelli integrativi', 3, 2), ('Pannelli integrativi', 3, 1), ('Sistema sanzionatorio', 3, 6), ('Sistema sanzionatorio', 3, 4),
                ('Sistema sanzionatorio', 3, 3), ('Sistema sanzionatorio', 3, 2), ('Sistema sanzionatorio', 3, 1), ('Massa complessiva e carichi', 4, 8),
                ('Sagoma limite dei veicoli', 4, 8), ('Sistemazione e fissaggio del carico', 5, 8), ('Stabilità del veicolo', 5, 8), ('Spazi di frenatura veicoli pesanti', 5, 8),
                ('Cronotachigrafo analogico e digitale', 5, 8), ('Tempi di guida e riposo', 5, 8), ('Limitazioni alla circolazione', 4, 8),
                ('Documenti trasporto merci', 4, 8), ('Responsabilità civile e penale', 5, 8), ('Complessi veicolari e motrici', 5, 9),
                ('Traino rimorchi superiori 3,5t', 5, 9), ('Stabilità complessi veicolari', 5, 9), ('Frenatura combinata e continua', 5, 9),
                ('Autocarri oltre 3,5 tonnellate', 4, 10), ('Assi e distribuzione del carico', 5, 10), ('Sospensioni pneumatiche', 4, 10),
                ('Impianto frenante ad aria', 5, 10), ('Trasporto merci pericolose ADR', 5, 10), ('Segnalazione carichi sporgenti', 4, 10), ('Trasporto eccezionale', 5, 10),
                ('Autoarticolati e autosnodati', 5, 11), ('Aggancio e sgancio semirimorchio', 5, 11), ('Frenatura pneumatica integrale', 5, 11),
                ('Stabilità in curva veicoli pesanti', 5, 11), ('Angoli ciechi mezzi pesanti', 5, 11), ('Complessi veicolari speciali', 5, 13), ('Traino rimorchio autobus', 5, 13),
                ('Trasporto pubblico di persone', 4, 14), ('Trasporto scolastico', 4, 14), ('Normativa trasporto persone', 5, 14), ('Uso porte automatiche e sicurezza', 4, 14),
                ('Sistemi antincendio autobus', 5, 14), ('Comportamento in caso di emergenza', 5, 14), ('Autosnodati con rimorchio', 5, 15),
                ('Manovre autobus articolati', 5, 15), ('Frenatura autobus con rimorchio', 5, 15), ('Macchine agricole operatrici', 3, 16), ('Circolazione mezzi agricoli', 3, 16),
                ('Traino attrezzi agricoli', 3, 16), ('Sagoma e limiti dimensionali agricoli', 3, 16), ('Sicurezza mezzi agricoli', 4, 16), ('Normativa taxi', 4, 17),
                ('Servizio NCC', 4, 17), ('Trasporto pubblico non di linea', 4, 17), ('Regolamenti comunali servizio pubblico', 4, 17), ('Responsabilità verso i passeggeri', 4, 17),
                ('Guida economica e razionale', 5, 19), ('Logistica e gestione aziendale', 5, 19), ('Normativa trasporto internazionale', 5, 19),
                ('Sicurezza professionale CQC', 5, 19), ('Prevenzione incidenti sul lavoro', 5, 19), ('Primo soccorso professionale', 4, 19),
                ('Gestione passeggeri e utenza', 5, 18), ('Normativa trasporto passeggeri', 5, 18), ('Sicurezza a bordo autobus', 5, 18),
                ('Relazione con utenti e disabili', 4, 18), ('Guida preventiva e difensiva', 5, 18), ('Primo soccorso a bordo', 4, 18)
            ]
            cursor.executemany(sql_cap, val_cap)
            
        cursor.execute("SELECT COUNT(*) as tot FROM quiz")
        if cursor.fetchone()['tot'] == 0:
            #quiz
            sql_quiz = "INSERT INTO quiz (difficolta, link_quiz, fk_patente) VALUES (%s, %s, %s)"
            val_quiz=[
                ('1','https://www.quizpatenteapp.com/quiz-ministeriali',6),('1','https://www.quizpatenteapp.com/quiz-ministeriali',4),
                ('1','https://www.quizpatenteapp.com/quiz-ministeriali',3),('1','https://www.quizpatenteapp.com/quiz-ministeriali',2),
                ('1','https://www.quizpatenteapp.com/quiz-ministeriali',1),('1','https://www.quizpatenteapp.com/quiz-ministeriali',6),
                ('1','https://www.quizpatenteapp.com/quiz-ministeriali',4),('1','https://www.quizpatenteapp.com/quiz-ministeriali',3),
                ('1','https://www.quizpatenteapp.com/quiz-ministeriali',2),('1','https://www.quizpatenteapp.com/quiz-ministeriali',1),
                ('1','https://www.quizpatenteapp.com/quiz-ministeriali',6),('1','https://www.quizpatenteapp.com/quiz-ministeriali',4),
                ('1','https://www.quizpatenteapp.com/quiz-ministeriali',3),('1','https://www.quizpatenteapp.com/quiz-ministeriali',2),
                ('1','https://www.quizpatenteapp.com/quiz-ministeriali',1),('2','https://www.quizpatenteapp.com/quiz-ministeriali',6),
                ('2','https://www.quizpatenteapp.com/quiz-ministeriali',4),('2','https://www.quizpatenteapp.com/quiz-ministeriali',3),
                ('2','https://www.quizpatenteapp.com/quiz-ministeriali',2),('2','https://www.quizpatenteapp.com/quiz-ministeriali',1),
                ('2','https://www.quizpatenteapp.com/quiz-ministeriali',6),('2','https://www.quizpatenteapp.com/quiz-ministeriali',4),
                ('2','https://www.quizpatenteapp.com/quiz-ministeriali',3),('2','https://www.quizpatenteapp.com/quiz-ministeriali',2),
                ('2','https://www.quizpatenteapp.com/quiz-ministeriali',1),('2','https://www.quizpatenteapp.com/quiz-ministeriali',6),
                ('2','https://www.quizpatenteapp.com/quiz-ministeriali',4),('2','https://www.quizpatenteapp.com/quiz-ministeriali',3),
                ('2','https://www.quizpatenteapp.com/quiz-ministeriali',2),('2','https://www.quizpatenteapp.com/quiz-ministeriali',1),
                ('1','https://www.quizpatenteapp.com/quiz-ministeriali',6),('1','https://www.quizpatenteapp.com/quiz-ministeriali',4),
                ('1','https://www.quizpatenteapp.com/quiz-ministeriali',3),('1','https://www.quizpatenteapp.com/quiz-ministeriali',2),
                ('1','https://www.quizpatenteapp.com/quiz-ministeriali',1),('2','https://www.quizpatenteapp.com/quiz-ministeriali',6),
                ('2','https://www.quizpatenteapp.com/quiz-ministeriali',4),('2','https://www.quizpatenteapp.com/quiz-ministeriali',3),
                ('2','https://www.quizpatenteapp.com/quiz-ministeriali',2),('2','https://www.quizpatenteapp.com/quiz-ministeriali',1),
                ('2','https://www.quizpatenteapp.com/quiz-ministeriali',6),('2','https://www.quizpatenteapp.com/quiz-ministeriali',4),
                ('2','https://www.quizpatenteapp.com/quiz-ministeriali',3),('2','https://www.quizpatenteapp.com/quiz-ministeriali',2),
                ('2','https://www.quizpatenteapp.com/quiz-ministeriali',1),('3','https://www.quizpatenteapp.com/quiz-ministeriali',6),
                ('3','https://www.quizpatenteapp.com/quiz-ministeriali',4),('3','https://www.quizpatenteapp.com/quiz-ministeriali',3),
                ('3','https://www.quizpatenteapp.com/quiz-ministeriali',2),('3','https://www.quizpatenteapp.com/quiz-ministeriali',1),
                ('2','https://www.quizpatenteapp.com/quiz-ministeriali',6),('2','https://www.quizpatenteapp.com/quiz-ministeriali',4),
                ('2','https://www.quizpatenteapp.com/quiz-ministeriali',3),('2','https://www.quizpatenteapp.com/quiz-ministeriali',2),
                ('2','https://www.quizpatenteapp.com/quiz-ministeriali',1),('3','https://www.quizpatenteapp.com/quiz-ministeriali',6),
                ('3','https://www.quizpatenteapp.com/quiz-ministeriali',4),('3','https://www.quizpatenteapp.com/quiz-ministeriali',3),
                ('3','https://www.quizpatenteapp.com/quiz-ministeriali',2),('3','https://www.quizpatenteapp.com/quiz-ministeriali',1),
                ('2','https://www.quizpatenteapp.com/quiz-ministeriali',6),('2','https://www.quizpatenteapp.com/quiz-ministeriali',4),
                ('2','https://www.quizpatenteapp.com/quiz-ministeriali',3),('2','https://www.quizpatenteapp.com/quiz-ministeriali',2),
                ('2','https://www.quizpatenteapp.com/quiz-ministeriali',1),('3','https://www.quizpatenteapp.com/quiz-ministeriali',6),
                ('3','https://www.quizpatenteapp.com/quiz-ministeriali',4),('3','https://www.quizpatenteapp.com/quiz-ministeriali',3),
                ('3','https://www.quizpatenteapp.com/quiz-ministeriali',2),('3','https://www.quizpatenteapp.com/quiz-ministeriali',1),
                ('3','https://www.quizpatenteapp.com/quiz-ministeriali',6),('3','https://www.quizpatenteapp.com/quiz-ministeriali',4),
                ('3','https://www.quizpatenteapp.com/quiz-ministeriali',3),('3','https://www.quizpatenteapp.com/quiz-ministeriali',2),
                ('3','https://www.quizpatenteapp.com/quiz-ministeriali',1),('3','https://www.quizpatenteapp.com/quiz-ministeriali',6),
                ('3','https://www.quizpatenteapp.com/quiz-ministeriali',4),('3','https://www.quizpatenteapp.com/quiz-ministeriali',3),
                ('3','https://www.quizpatenteapp.com/quiz-ministeriali',2),('3','https://www.quizpatenteapp.com/quiz-ministeriali',1),
                ('3','https://www.quizpatenteapp.com/quiz-ministeriali',6),('3','https://www.quizpatenteapp.com/quiz-ministeriali',4),
                ('3','https://www.quizpatenteapp.com/quiz-ministeriali',3),('3','https://www.quizpatenteapp.com/quiz-ministeriali',2),
                ('3','https://www.quizpatenteapp.com/quiz-ministeriali',1),('4','https://www.quizpatenteapp.com/quiz-ministeriali',6),
                ('4','https://www.quizpatenteapp.com/quiz-ministeriali',4),('4','https://www.quizpatenteapp.com/quiz-ministeriali',3),
                ('4','https://www.quizpatenteapp.com/quiz-ministeriali',2),('4','https://www.quizpatenteapp.com/quiz-ministeriali',1),
                ('3','https://www.quizpatenteapp.com/quiz-ministeriali',6),('3','https://www.quizpatenteapp.com/quiz-ministeriali',4),
                ('3','https://www.quizpatenteapp.com/quiz-ministeriali',3),('3','https://www.quizpatenteapp.com/quiz-ministeriali',2),
                ('3','https://www.quizpatenteapp.com/quiz-ministeriali',1),('2','https://www.quizpatenteapp.com/quiz-ministeriali',6),
                ('2','https://www.quizpatenteapp.com/quiz-ministeriali',4),('2','https://www.quizpatenteapp.com/quiz-ministeriali',3),
                ('2','https://www.quizpatenteapp.com/quiz-ministeriali',2),('2','https://www.quizpatenteapp.com/quiz-ministeriali',1),
                ('2','https://www.quizpatenteapp.com/quiz-ministeriali',6),('2','https://www.quizpatenteapp.com/quiz-ministeriali',4),
                ('2','https://www.quizpatenteapp.com/quiz-ministeriali',3),('2','https://www.quizpatenteapp.com/quiz-ministeriali',2),
                ('2','https://www.quizpatenteapp.com/quiz-ministeriali',1),('2','https://www.quizpatenteapp.com/quiz-ministeriali',6),
                ('2','https://www.quizpatenteapp.com/quiz-ministeriali',4),('2','https://www.quizpatenteapp.com/quiz-ministeriali',3),
                ('2','https://www.quizpatenteapp.com/quiz-ministeriali',2),('2','https://www.quizpatenteapp.com/quiz-ministeriali',1),
                ('4','https://www.quizpatenteapp.com/quiz-ministeriali',6),('4','https://www.quizpatenteapp.com/quiz-ministeriali',4),
                ('4','https://www.quizpatenteapp.com/quiz-ministeriali',3),('4','https://www.quizpatenteapp.com/quiz-ministeriali',2),
                ('4','https://www.quizpatenteapp.com/quiz-ministeriali',1),('3','https://www.quizpatenteapp.com/quiz-ministeriali',6),
                ('3','https://www.quizpatenteapp.com/quiz-ministeriali',4),('3','https://www.quizpatenteapp.com/quiz-ministeriali',3),
                ('3','https://www.quizpatenteapp.com/quiz-ministeriali',2),('3','https://www.quizpatenteapp.com/quiz-ministeriali',1),
                ('3','https://www.quizpatenteapp.com/quiz-ministeriali',6),('3','https://www.quizpatenteapp.com/quiz-ministeriali',4),
                ('3','https://www.quizpatenteapp.com/quiz-ministeriali',3),('3','https://www.quizpatenteapp.com/quiz-ministeriali',2),
                ('3','https://www.quizpatenteapp.com/quiz-ministeriali',1)
            ]
            cursor.executemany(sql_quiz, val_quiz)
        cursor.execute("SELECT COUNT(*) as tot FROM lezioni")
        if cursor.fetchone()['tot'] == 0:
            #LEZIONI
            sql_lez = "INSERT INTO lezioni (durata_lezione, data_lezione, aula_meet, orario, fk_capitolo) VALUES"
            val_lez = [
                (60, '2026-04-06', 'https://meet.google.com/abc-111-aaa', '09:00:00', 1),
                (45, '2026-04-06', 'https://meet.google.com/abc-111-aaa', '11:00:00', 2),
                (90, '2026-04-07', 'https://meet.google.com/def-222-bbb', '14:30:00', 3),
                (30, '2026-04-08', 'https://meet.google.com/ghi-333-ccc', '10:00:00', 4),
                (60, '2026-04-09', 'https://meet.google.com/jkl-444-ddd', '09:30:00', 5),
                (45, '2026-04-10', 'https://meet.google.com/mno-555-eee', '16:00:00', 6),
                (120, '2026-04-13', 'https://meet.google.com/pqr-666-fff', '14:00:00', 15),
                (60, '2026-04-14', 'https://meet.google.com/stu-777-ggg', '09:00:00', 16),
                (45, '2026-04-14', 'https://meet.google.com/stu-777-ggg', '10:30:00', 17),
                (90, '2026-04-15', 'https://meet.google.com/vwx-888-hhh', '15:00:00', 20),
                (30, '2026-04-16', 'https://meet.google.com/yza-999-iii', '11:00:00', 25),
                (60, '2026-04-17', 'https://meet.google.com/bcd-000-jjj', '09:00:00', 30),
                (150, '2026-04-20', 'https://meet.google.com/efe-121-kkk', '14:30:00', 45),
                (45, '2026-04-21', 'https://meet.google.com/ghg-232-lll', '09:00:00', 50),
                (45, '2026-04-21', 'https://meet.google.com/ghg-232-lll', '10:00:00', 51),
                (60, '2026-04-22', 'https://meet.google.com/iji-343-mmm', '15:30:00', 60),
                (30, '2026-04-23', 'https://meet.google.com/klk-454-nnn', '11:15:00', 65),
                (90, '2026-04-24', 'https://meet.google.com/mnm-565-ooo', '09:00:00', 70),
                (60, '2026-04-27', 'https://meet.google.com/opo-676-ppp', '10:00:00', 90),
                (120, '2026-04-28', 'https://meet.google.com/qrq-787-qqq', '14:00:00', 92),
                (45, '2026-04-29', 'https://meet.google.com/sts-898-rrr', '09:00:00', 95),
                (60, '2026-04-30', 'https://meet.google.com/utu-909-sss', '16:00:00', 100),
                (90, '2026-05-11', 'https://meet.google.com/vwv-010-ttt', '14:00:00', 150),
                (45, '2026-05-12', 'https://meet.google.com/xyx-121-uuu', '10:30:00', 160),
                (60, '2026-05-13', 'https://meet.google.com/zyz-232-vvv', '11:00:00', 170),
                (120, '2026-05-14', 'https://meet.google.com/aba-343-www', '15:00:00', 180),
                (60, '2026-05-15', 'https://meet.google.com/cdc-454-xxx', '09:00:00', 183),
                (180, '2026-05-15', 'https://meet.google.com/cdc-454-xxx', '14:00:00', 184)
            ]
            cursor.executemany(sql_lez, val_lez)
            
        cursor.execute("SELECT COUNT(*) as tot FROM prenotazioni")
        if cursor.fetchone()['tot'] == 0:
            # PRENOTAZIONI (Tutte quelle fornite)
            sql_pre = "INSERT INTO prenotazioni (tipo_prenotazione, costo_prenotazione, data_prenotazione, orario) VALUES (%s, %s, %s, %s)"
            val_pre = [
                ('guida', 25, '2026-04-13', '08:00:00'), ('guida', 25, '2026-04-13', '09:00:00'),
                ('visita amnestica', 50, '2026-04-13', '10:30:00'), ('esame teorico', 360, '2026-04-13', '14:30:00'),
                ('visita oculistica', 65, '2026-04-14', '08:30:00'), ('esame pratico', 160, '2026-04-14', '14:00:00'),
                ('guida', 25, '2026-04-14', '17:00:00'),('visita amnestica', 50, '2026-04-15', '09:00:00'),('guida', 25, '2026-04-15', '10:00:00'),
                ('guida', 25, '2026-04-15', '11:00:00'),('esame teorico', 360, '2026-04-15', '15:00:00'),('visita oculistica', 65, '2026-04-15', '17:30:00'),
                ('guida', 25, '2026-04-16', '08:00:00'),('esame pratico', 160, '2026-04-16', '09:00:00'),('guida', 25, '2026-04-16', '11:30:00'),
                ('guida', 25, '2026-04-16', '14:30:00'),('visita amnestica', 50, '2026-04-16', '16:00:00'),('guida', 25, '2026-04-16', '18:00:00'),
                ('guida', 25, '2026-04-17', '08:30:00'),('visita oculistica', 65, '2026-04-17', '10:00:00'),('esame teorico', 360, '2026-04-17', '11:00:00'),
                ('guida', 25, '2026-04-17', '14:00:00'),('guida', 25, '2026-04-17', '15:00:00'),('esame pratico', 160, '2026-04-17', '16:30:00'),   
                ('guida', 25, '2026-04-18', '09:00:00'),('guida', 25, '2026-04-18', '10:00:00'),('visita amnestica', 50, '2026-04-20', '08:30:00'),
                ('guida', 25, '2026-04-20', '09:30:00'),('visita oculistica', 65, '2026-04-20', '11:00:00'),('guida', 25, '2026-04-20', '15:00:00'),('esame teorico', 360, '2026-04-21', '09:00:00'),
                ('guida', 25, '2026-04-21', '11:00:00'),('guida', 25, '2026-04-21', '12:00:00'),('esame pratico', 160, '2026-04-21', '14:30:00'),
                ('guida', 25, '2026-04-21', '16:30:00'),('visita amnestica', 50, '2026-04-22', '10:00:00'),('guida', 25, '2026-04-22', '11:00:00'),
                ('visita oculistica', 65, '2026-04-22', '15:30:00'),('guida', 25, '2026-04-22', '17:00:00'),('esame teorico', 360, '2026-04-23', '08:30:00'),
                ('guida', 25, '2026-04-23', '10:30:00'),('esame pratico', 160, '2026-04-23', '14:00:00'),('guida', 25, '2026-04-23', '16:00:00'),
                ('guida', 25, '2026-04-24', '09:00:00'),('visita oculistica', 65, '2026-04-24', '11:30:00'),('guida', 25, '2026-04-24', '14:30:00')
            ]
            cursor.executemany(sql_pre, val_pre)

            cnx_sql.commit()
            print("[SETUP] Dati inseriti con successo.")

        cursor.close()
        print("--- [SETUP] Pronto! ---")
        
    except mysql.connector.Error as err:
        print(f"!!! ERRORE DATABASE: {err}")
        raise # Rilancia l'errore per fermare l'avvio se il DB fallisce
    finally:
        if cursor:
            cursor.close()
        if cnx_sql:
            cnx_sql.close() # Chiudiamo la connessione di setup
   
#######################################

#FUNZIONI PER IL FUNZIONAMENTO DELLE APP ROUTE

#mi genere le pw hashate
def hash_password(pw):
    return hashlib.sha256(pw.encode()).hexdigest()

#mi fa il calcolo dell'età
def calcoloEta(data):
    anno=datetime.date.today().year
    mese=datetime.date.today().month
    giorno=datetime.date.today().day
    if anno<data.year:
        calcolo=0
    else:
        calcolo=anno-(data.year)
        if mese<data.month or (mese==data.month and giorno<data.day):
            calcolo-=1 #faccio -1 perchè significa che NON ha già compiuto gli anni
    return calcolo
# mi calcolo all'epoca quanti anni aveva 
def calcoloEtaStorica(nascita, riferimento):
    eta = riferimento.year - nascita.year
    if (riferimento.month, riferimento.day) < (nascita.month, nascita.day):
        eta -= 1
    return eta
#prendo il ruolo del'utente per vedere se è un istruttore o uno studente
def get_ruolo(id_utente):
    db=get_db()
    cursor=db.cursor()
    query= """
        SELECT nome_ruolo
        FROM ruoli JOIN utenti
            ON id_ruolo=fk_ruolo
        WHERE id_utente=%s
    """
    cursor.execute(query,(id_utente,))
    ris=cursor.fetchone()
    cursor.close()
    db.close()
    
    return ris[0]
    
#######################################

#APP ROUTE PER IL DATABASE

#INSERISCI UTENTE
@app.route('/iscriviti', methods=['POST'])
def post_iscriviti():
    #Recupero dati dal form
    nome_utente = request.form['nome']
    cognome_utente = request.form['cognome']
    cf = request.form['cf']
    email = request.form['email']  
    pw_hash = hash_password(request.form['pw'])
    data_nascita = request.form['data_nascita']
    data_oggi = datetime.date.today()
    codice_attivazione = request.form['codice']
    stato_account = ""
    data_nascita_obj = datetime.datetime.strptime(data_nascita, '%Y-%m-%d').date()
    
    # Controllo Età minima (14 anni)
    if calcoloEta(data_nascita_obj) < 14:
        cnx_redis.set("msg", "DEVI AVERE ALMENO 14 ANNI PER ISCRIVERTI!")
        return render_template("home.html", msg=cnx_redis.get("msg"), msg_type='danger')
    
    #Verifica codice attivazione
    if codice_attivazione in ['123', '456']:
        db = get_db() #mi connetto con il database
        cursor = db.cursor() 
        try:
            #Recupero l'ID del ruolo
            cursor.execute("SELECT id_ruolo FROM ruoli WHERE codice_attivazione = %s", (codice_attivazione,))
            ris = cursor.fetchone()
            if ris:
                fk_ruolo = ris[0]
                #Inserimento Utente
                query_insert = """
                    INSERT INTO utenti 
                    (nome_utente, cognome_utente, cf, email, password, data_nascita, 
                     stato_account, ultimo_accesso, data_iscrizione, fk_ruolo)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
                cursor.execute(query_insert, (
                    nome_utente, cognome_utente, cf, email, pw_hash, 
                    data_nascita, stato_account, data_oggi, data_oggi, fk_ruolo
                ))
                
                #guardo il risultato e mi salvo il messaggio
                if cursor.rowcount > 0:
                    id_utente = cursor.lastrowid
                    cnx_redis.set("accesso_eseguito", id_utente)
                    cnx_redis.set("msg", "UTENTE INSERITO CORRETTAMENTE!")
                    msg_type='success'
                    return render_template("home.html", msg=cnx_redis.get("msg"),msg_type=msg_type ,accesso=cnx_redis.get("accesso_eseguito"),ruolo=get_ruolo(cnx_redis.get("accesso_eseguito")))
                else:
                    cnx_redis.set("msg", "ERRORE DURANTE L'INSERIMENTO!")
                    msg_type='danger'
                    return render_template("home.html", msg=cnx_redis.get("msg"),msg_type=msg_type)
            else:
                cnx_redis.set("msg", "RUOLO NON TROVATO PER QUESTO CODICE!")
                msg_type='danger'
                return render_template("home.html", msg=cnx_redis.get("msg"),msg_type=msg_type)
        except Exception as e:
            print(f"Errore DB: {e}")
            cnx_redis.set("msg", "ERRORE TECNICO NEL DATABASE")
            msg_type='danger'
            return render_template("home.html", msg=cnx_redis.get("msg"),msg_type=msg_type)
        finally:
            # CHIUDI SEMPRE qui, così libero la risorsa per la prossima richiesta
            cursor.close()
            db.close()
    else:
        cnx_redis.set("msg", "CODICE INSERITO NON VALIDO")
        msg_type='danger'
        return render_template("home.html", msg=cnx_redis.get("msg"),msg_type=msg_type)
        

#LOGIN UTENTE
@app.route('/login', methods=['POST'])
def post_login():
    #Recupero dati dal form
    email = request.form['email']
    pw_hash = hash_password(request.form['pw'])
    data_accesso = datetime.date.today()
    id_utente = None
    #Gestione Database
    db = get_db()
    cursor = db.cursor()
    try:
        #Cerco l'utente
        cursor.execute("SELECT id_utente FROM utenti WHERE email=%s AND password=%s", (email, pw_hash))
        row = cursor.fetchone()
        if row is not None:
            id_utente = row[0]
            # Aggiorno la data dell'ultimo accesso
            cursor.execute("UPDATE utenti SET ultimo_accesso=%s WHERE id_utente=%s", (data_accesso, id_utente))
            db.commit() 
    except Exception as e:
        print(f"Errore durante il login: {e}")
        cnx_redis.set("msg", "ERRORE TECNICO DURANTE IL LOGIN")
        msg_type='danger'
        return render_template("home.html", msg=cnx_redis.get("msg"),msg_type=msg_type)
    finally:
        cursor.close()
        db.close()

    #Verifica risultato e gestione sessione tramite Redis
    if id_utente is not None:
        cnx_redis.set("accesso_eseguito", id_utente)
        cnx_redis.set("msg", "LOGIN EFFETTUATO!")
        msg_type='success'
        return render_template("home.html", msg=cnx_redis.get("msg"),msg_type=msg_type ,accesso=cnx_redis.get("accesso_eseguito"),ruolo=get_ruolo(cnx_redis.get("accesso_eseguito")))
    else:
        # Se il login fallisce, puliamo eventuali sessioni precedenti
        cnx_redis.delete("accesso_eseguito")
        cnx_redis.set("msg", "EMAIL O PASSWORD ERRATI")
        msg_type='danger'
        return render_template("home.html", msg=cnx_redis.get("msg"),msg_type=msg_type)

#ESCI DAL LOGIN     
@app.route('/esci', methods=['GET', 'POST'])
def post_esci():
    cnx_redis.delete("accesso_eseguito")
    cnx_redis.set("msg","SEI USCITO DALL'ACOUNT!")
    return redirect(url_for("home"))

#PRENOTAZIONE
@app.route('/ricevuta', methods=['POST'])
def post_ricevuta():
    dati = request.form['dati_per_prenotare']
    metodo = request.form['tipo_pagamento']
    id_utente = cnx_redis.get("accesso_eseguito")
    
    if not id_utente:
        return redirect(url_for('login')) 

    # Preparazione dati carta per il template
    carta = {'tipologia': metodo}
    if metodo == "carta":
        carta['numero_carta'] = request.form['numero_carta']
        carta['scadenza'] = request.form['scadenza']
        carta['cvv'] = request.form['cvv']

    # Stato del pagamento basato sul metodo
    if metodo == "carta":
        stato_pagamento = "pagato"
    else:
        stato_pagamento = "pagare in sede"
    prezzo = 0
    dati_pre = []

    db = get_db()
    cursor = db.cursor(dictionary=True)
    try:
        #Recupero stato utente
        cursor.execute("SELECT stato_account FROM utenti WHERE id_utente=%s", (id_utente,))
        utente = cursor.fetchone()
        #guardo se è stato pratico,teorico oppure nuovo per capire cosa ha prenotato
        if utente:
            if utente['stato_account']:
                stato = utente['stato_account']
            else:
                stato = ""
        else:
            stato = ""

        #PRIMA ISCRIZIONE A UNA PATENTE (Stato vuoto)
        if not stato:
            cursor.execute("SELECT costo FROM patenti WHERE id_patente=%s", (dati,))
            res = cursor.fetchone()
            prezzo = res['costo'] + 250
            
            # Aggiorno utente, creo legame patente e inserisco pagamento
            cursor.execute("UPDATE utenti SET stato_account='teorico' WHERE id_utente=%s", (id_utente,))
            cursor.execute("INSERT INTO ute_pat (fk_utente, fk_patente) VALUES (%s,%s)", (id_utente, dati))
            cursor.execute("""
                INSERT INTO pagamenti (metodo_pagamento, totale_pagamento, stato_pagamento)
                VALUES (%s,%s,%s)
            """, (metodo, prezzo, stato_pagamento))
            
            # Recupero dati per il template (INFO PATENTE)
            cursor.execute("SELECT * FROM patenti WHERE id_patente=%s", (dati,))
            dati_pre = cursor.fetchall()
        #PRENOTAZIONE SERVIZIO (Guida, Esame, Visita)
        else:
            cursor.execute("SELECT * FROM prenotazioni WHERE id_prenotazione=%s AND fk_utente IS NULL", (dati,))
            pren = cursor.fetchone()
            #se non c'è lo rispedisco a prenotare
            if not pren:
                return redirect(url_for("prenotazione"))

            tipo = pren['tipo_prenotazione']
            # Controllo duplicati (tranne per le guide)
            cursor.execute("""
                SELECT COUNT(*) as tot FROM prenotazioni
                WHERE fk_utente=%s AND tipo_prenotazione=%s
            """, (id_utente, tipo))
            
            #se ha già prenotato visite o esami non puoò prenotarne altri
            if cursor.fetchone()['tot'] > 0 and tipo != "guida":
                return redirect(url_for("prenotazione"))

            prezzo = pren['costo_prenotazione']
            
            # Inserisco pagamento e aggiorno la prenotazione
            cursor.execute("""
                INSERT INTO pagamenti (metodo_pagamento, totale_pagamento, stato_pagamento)
                VALUES (%s,%s,%s)
            """, (metodo, prezzo, stato_pagamento))
            id_pagamento_nuovo = cursor.lastrowid
            cursor.execute("""
                UPDATE prenotazioni 
                SET fk_utente = %s, fk_pagamento = %s
                WHERE id_prenotazione = %s
            """, (id_utente, id_pagamento_nuovo, dati))
            
            # Recupero dati per la ricevuta
            cursor.execute("SELECT * FROM prenotazioni WHERE id_prenotazione=%s", (dati,))
            dati_pre = cursor.fetchall()
        db.commit()
    except Exception as e:
        print(f"ERRORE RICEVUTA: {e}")
        db.rollback() # Annulla tutto se c'è un errore a metà
        return "Errore durante l'elaborazione", 500
    finally:
        cursor.close()
        db.close()
        
    return render_template("ricevuta.html", dati_carta=carta, dati_prenotazione=dati_pre, prezzo=prezzo, stato_pagamento=stato_pagamento, accesso=id_utente,ruolo=get_ruolo(id_utente))

# ASSEGNAZIONE PATENTE
@app.route('/scelta_patente', methods=['POST'])
def post_patenti():
    patente_scelta = request.form['patente']
    data_conseguimento_str = request.form['data_conseguimento']
    fk_utente = cnx_redis.get("accesso_eseguito")
    
    if not fk_utente:
        return redirect(url_for('login')) 

    db = get_db()
    cursor = db.cursor(dictionary=True)
    try:
        # 1. Recuperiamo la data di nascita dell'utente e l'età minima della patente
        cursor.execute("SELECT data_nascita FROM utenti WHERE id_utente = %s", (fk_utente,))
        utente = cursor.fetchone()
        
        cursor.execute("SELECT eta_minima FROM patenti WHERE id_patente = %s", (patente_scelta,))
        patente_info = cursor.fetchone()

        if utente and patente_info:
            data_nascita = utente['data_nascita']
            eta_minima_richiesta = patente_info['eta_minima']
            
            # Convertiamo la data di conseguimento in oggetto date
            data_cons_obj = datetime.datetime.strptime(data_conseguimento_str, '%Y-%m-%d').date()
            eta_al_conseguimento = calcoloEtaStorica(data_nascita, data_cons_obj)

            # 2. Controllo validità
            if eta_al_conseguimento < eta_minima_richiesta:
                cnx_redis.set("msg", f"ERRORE: Alla data indicata avevi {eta_al_conseguimento} anni. Per questa patente ne servono almeno {eta_minima_richiesta}!")
                return render_template("home.html", msg=cnx_redis.get("msg"), msg_type="danger", accesso=fk_utente, ruolo=get_ruolo(fk_utente))

        # 3. Procediamo con l'inserimento se il controllo è passato
        cursor.execute("""
            INSERT INTO ute_pat (data_conseguimento, fk_utente, fk_patente) 
            VALUES (%s, %s, %s)
        """, (data_conseguimento_str, fk_utente, patente_scelta))
        db.commit()

        if cursor.rowcount > 0:
            cnx_redis.set("msg", "PATENTE INSERITA CORRETTAMENTE!")
            msg_type="success"
            return render_template("home.html", msg=cnx_redis.get("msg"), msg_type=msg_type, accesso=fk_utente, ruolo=get_ruolo(fk_utente))
        else:
            cnx_redis.set("msg", "ERRORE NELL'INSERIMENTO!")
            msg_type="danger"
            return render_template("home.html", msg=cnx_redis.get("msg"),msg_type=msg_type)

    except Exception as e:
        print(f"Errore inserimento patente: {e}")
        cnx_redis.set("msg", "ERRORE TECNICO DATABASE")
        msg_type="danger"
        return render_template("home.html", msg=cnx_redis.get("msg"),msg_type=msg_type)
    finally:
        cursor.close()
        db.close()
    
#FA VEDERE TUTTI GLI ISTRUTTORI
@app.route('/chisiamo', methods=['GET'])
def get_chisiamo():
    dati_istrut = []
    db = get_db()
    cursor = db.cursor(dictionary=True)
    try:
        # fk_ruolo=2 sono gli istruttori
        cursor.execute("SELECT * FROM utenti WHERE fk_ruolo=2")
        dati_istrut = cursor.fetchall()
    except Exception as e:
        print(f"Errore caricamento istruttori: {e}")
    finally:
        cursor.close()
        db.close()
        
    return render_template("chisiamo.html", dati_istruttori=dati_istrut,accesso=cnx_redis.get("accesso_eseguito"))

#GESTIONE DELLE LEZIONI
@app.route('/lezioni', methods=['GET'])
def get_lezioni():
    id_utente = cnx_redis.get("accesso_eseguito")
    
    if not id_utente:
        return redirect(url_for('login'))
    
    db = get_db()
    cursor = db.cursor(dictionary=True)
    
    try:
        #mi prende le lezioni dalla data di oggi in poi non più quelle passate
        query = """
              SELECT l.durata_lezione, l.data_lezione, l.aula_meet, l.orario, c.nome_capitolo, c.difficolta, p.tipologia_patente
            FROM capitoli c JOIN lezioni l 
		ON c.id_capitolo = l.fk_capitolo
            JOIN patenti p 
		ON p.id_patente = c.fk_patente
            WHERE l.data_lezione >= CURDATE() AND (l.data_lezione > CURDATE() OR l.orario >= CURTIME()) AND p.id_patente IN (SELECT fk_patente
																	FROM ute_pat
																	WHERE fk_utente = %s AND data_conseguimento IS NULL)
            ORDER BY l.data_lezione ASC, l.orario ASC
        """
        cursor.execute(query, (id_utente,))
        dati_lezioni = cursor.fetchall()

    except Exception as e:
        print(f"Errore nel recupero lezioni: {e}")
        dati_lezioni = [] # In caso di errore restituiamo lista vuota

    finally:
        cursor.close()
        
    return render_template("lezioni.html", dati_lezioni=dati_lezioni, accesso=id_utente)
        
#RESTITUISCE I QUIZ
@app.route('/quiz', methods=['GET'])
def get_quiz():
    id_utente = cnx_redis.get("accesso_eseguito")
    if not id_utente:
        return redirect(url_for('login')) 

    dati_quiz = []
    stato_utente = None
    db = get_db()
    cursor = db.cursor(dictionary=True)
    
    try:
        #prendo lo stato e la patente ATTIVA
        query_info = """
            SELECT stato_account, tipologia_patente
            FROM utenti 
            JOIN ute_pat ON id_utente = fk_utente
            JOIN patenti ON id_patente = fk_patente
            WHERE id_utente = %s AND data_conseguimento IS NULL
        """
        cursor.execute(query_info, (id_utente,))
        info_utente = cursor.fetchone()
        
        if info_utente:
            stato_utente = info_utente['stato_account']
            
            if stato_utente == 'teorico':
                #Carico i quiz relativi SOLO alla patente attiva
                query_quiz = """
                    SELECT DISTINCT q.id_quiz, q.difficolta, q.link_quiz,c.nome_capitolo, p.tipologia_patente
                    FROM ute_pat AS up JOIN patenti AS p 
                        ON up.fk_patente = p.id_patente
                    JOIN capitoli AS c 
                        ON c.fk_patente = p.id_patente
                    JOIN quiz AS q 
                        ON q.fk_capitolo = c.id_capitolo
                    WHERE up.fk_utente = %s AND up.data_conseguimento IS NULL
                """
                cursor.execute(query_quiz, (id_utente,))
                dati_quiz = cursor.fetchall()
        
    except Exception as e:
        print(f"Errore nel recupero quiz: {e}")
    finally:
        cursor.close()
        db.close()

    return render_template("quiz.html", dati_quiz=dati_quiz,stato=stato_utente,accesso=id_utente)

#INSERISCE LE STATISTICHE
@app.route('/inserisci_statistiche', methods=['GET', 'POST'])
def inserisci_statistiche():
    id_utente = cnx_redis.get("accesso_eseguito")
    if not id_utente:
        return redirect(url_for('login'))

    if request.method == 'POST':
        id_capitolo = request.form.get('id_capitolo')
        errori_input = request.form.get('errori')

        if not id_capitolo or not errori_input:
            return "Errore: devi selezionare un capitolo e inserire il numero di errori."

        try:
            errori = int(errori_input)
        except ValueError:
            return "Errore: il numero di errori deve essere un numero intero."

        tag = f"capitolo_{id_capitolo}"
        somma_errori = int(cnx_redis.get(f"somma_errori:{tag}:{id_utente}") or 0)
        numero_quiz = int(cnx_redis.get(f"num_quiz:{tag}:{id_utente}") or 0)

        cnx_redis.set(f"somma_errori:{tag}:{id_utente}", somma_errori + errori)
        cnx_redis.set(f"num_quiz:{tag}:{id_utente}", numero_quiz + 1)
        cnx_redis.set(f"media:{tag}:{id_utente}", (somma_errori + errori) / (numero_quiz + 1))

        return redirect(url_for('visualizza_statistiche'))

    db = get_db()
    cursor = db.cursor(dictionary=True)
    try:
        query = """
            SELECT c.id_capitolo, c.nome_capitolo 
            FROM capitoli AS c 
            JOIN patenti AS p ON c.fk_patente = p.id_patente
            JOIN ute_pat AS up ON p.id_patente = up.fk_patente
            WHERE up.fk_utente = %s AND up.data_conseguimento IS NULL
        """
        cursor.execute(query, (id_utente,))
        dati_capitoli = cursor.fetchall()
    finally:
        cursor.close()
        db.close()

    return render_template("inserisci_statistiche.html", dati_capitoli=dati_capitoli, accesso=id_utente)

#VISUALIZZA LE STATISTICHE
@app.route('/visualizza_statistiche', methods=['GET'])
def get_visualizza_statistiche():
    id_utente = cnx_redis.get("accesso_eseguito")
    if not id_utente:
        return redirect(url_for('login')) 
    
    # Inizializzo la struttura dati che passerò al template
    stats = {
        'capitoli': []
    }
    
    #recupero quelle dei capitoli
    db = get_db()
    cursor = db.cursor(dictionary=True)
    try:
        #Cerco i capitoli della patente che l'utente non ha ancora preso
        query = """
            SELECT id_capitolo, nome_capitolo
            FROM capitoli
            WHERE fk_patente = (
                SELECT fk_patente
                FROM ute_pat
                WHERE fk_utente = %s AND data_conseguimento IS NULL
            )
        """
        cursor.execute(query, (id_utente,))
        capitoli_db = cursor.fetchall()
        
        for capitolo in capitoli_db:
            id_cap = capitolo['id_capitolo']
            nome_cap = capitolo['nome_capitolo']
            tag_cap = f"capitolo_{id_cap}"
            
            # Prendo i dati specifici del capitolo da Redis
            r_err_c = cnx_redis.get(f"somma_errori:{tag_cap}:{id_utente}")
            r_quiz_c = cnx_redis.get(f"num_quiz:{tag_cap}:{id_utente}")
            r_media_c = cnx_redis.get(f"media:{tag_cap}:{id_utente}")

            if r_err_c:
                val_err = int(r_err_c)
            else:
                val_err = 0
            if r_quiz_c:
                val_quiz = int(r_quiz_c)
            else:
                val_quiz = 0
            if r_media_c:
                val_media = round(float(r_media_c), 2)
            else:
                val_media = 0

            # Aggiungo il dizionario del capitolo alla lista
            stats['capitoli'].append({
                "capitolo": nome_cap,
                "errori": val_err,
                "quiz": val_quiz,
                "media": val_media
            })

    except Exception as e:
        print(f"Errore caricamento statistiche: {e}")
    finally:
        cursor.close()
        db.close()

    return render_template("visualizza_statistiche.html", stats=stats, accesso=id_utente)

#FA VEDERE LE PRENOTAZIONI DELL'UTENTE
@app.route('/agenda', methods=['GET'])
def agenda():
    id_utente = cnx_redis.get("accesso_eseguito")
    if not id_utente:
        return redirect(url_for('login'))

    db = get_db()
    cursor = db.cursor(dictionary=True)
    try:
        query = """
            SELECT *
            FROM prenotazioni
            WHERE fk_utente = %s
            ORDER BY data_prenotazione ASC, orario_prenotazione ASC
        """
        cursor.execute(query, (id_utente,))
        prenotazioni = cursor.fetchall()
    finally:
        cursor.close()
        db.close()

    return render_template("agenda.html", prenotazioni=prenotazioni, accesso=id_utente)

#GESTIONE UTENTI PER ISTRUTTORE
@app.route('/gestione_utenti', methods=['GET'])
def gestione_utenti():
    user_id = cnx_redis.get("accesso_eseguito")

    if not user_id:
        return redirect(url_for("login"))

    ruolo = get_ruolo(user_id)
    if ruolo != "Istruttore":
        return redirect(url_for("home"))

    db = get_db()
    cursor = db.cursor(dictionary=True)
    dati_utenti = []
    try:
        cursor.execute("SELECT * FROM utenti WHERE fk_ruolo=1")
        dati_utenti = cursor.fetchall()
    except Exception as e:
        print(f"Errore: {e}")
    finally:
        cursor.close()
        db.close()


    return render_template("gestione_utenti.html",dati_utenti=dati_utenti,accesso=user_id,ruolo=ruolo)

#FA VEDER TUTTE LE PRENOTAZIONI
@app.route("/gestione_prenotazioni", methods=['GET'])
def gestione_prenotazioni():
    user_id = cnx_redis.get("accesso_eseguito")

    if not user_id:
        return redirect(url_for("login"))

    ruolo = get_ruolo(user_id)
    if ruolo != "Istruttore":
        return redirect(url_for("home"))
    
    db = get_db()
    cursor = db.cursor(dictionary=True)
    dati_prenotazioni = []
    try:
        cursor.execute("""
                SELECT * FROM prenotazioni 
                WHERE AND data_prenotazione >= CURDATE() AND (data_prenotazione > CURDATE() OR orario_prenotazione >= CURTIME())
                ORDER BY data_prenotazione ASC, orario_prenotazione ASC
                       """)
        dati_prenotazioni = cursor.fetchall()
    except Exception as e:
        print(f"Errore: {e}")
    finally:
        cursor.close()
        db.close()


    return render_template("gestione_prenotazioni.html",dati_prenotazioni=dati_prenotazioni,accesso=user_id,ruolo=ruolo)

#FA VEDER TUTTE LE LEZIONI
@app.route("/gestione_lezioni", methods=['GET'])
def gestione_lezioni():
    user_id = cnx_redis.get("accesso_eseguito")

    if not user_id:
        return redirect(url_for("login"))

    ruolo = get_ruolo(user_id)
    if ruolo != "Istruttore":
        return redirect(url_for("home"))
    
    db = get_db()
    cursor = db.cursor(dictionary=True)
    dati_lezioni = []
    try:
        cursor.execute("""
        SELECT *
            FROM lezioni 
            WHERE data_lezione >= CURDATE() AND (data_lezione > CURDATE() OR orario >= CURTIME()) 
            ORDER BY data_lezione ASC, orario ASC
                       """)
        dati_lezioni = cursor.fetchall()
    except Exception as e:
        print(f"Errore: {e}")
    finally:
        cursor.close()
        db.close()


    return render_template("gestione_lezioni.html",dati_lezioni=dati_lezioni,accesso=user_id,ruolo=ruolo)

#MODIFICA UTENTI
@app.route("/modifica_utente/<int:id_utente>", methods=["GET", "POST"])
def modifica_utente(id_utente):

    if not id_utente:
        return redirect(url_for("login"))

    db = get_db()
    cursor = db.cursor(dictionary=True)
    if request.method == "POST":
        nome = request.form["nome_utente"]
        cognome = request.form["cognome_utente"]
        email = request.form["email"]
        codice_fiscale = request.form["cf"]
        data_nascita = request.form["data_nascita"]
        stato = request.form["stato_account"]

        query = """
            UPDATE utenti 
            SET nome_utente=%s, cognome_utente=%s, email=%s, cf=%s, stato_account=%s , data_nascita=%s
            WHERE id_utente=%s
        """
        cursor.execute(query, (nome, cognome, email, codice_fiscale, stato, data_nascita ,id_utente))
        db.commit()
        
        return redirect(url_for('gestione_utenti'))

    cursor.execute("SELECT * FROM utenti WHERE id_utente = %s", (id_utente,))
    utente = cursor.fetchone()
    
    return render_template("modifica_utente.html", utente=utente)

#MODIFICA PRENOTAZIONE
@app.route("/modifica_prenotazione/<int:id_prenotazione>", methods=["GET", "POST"])
def modifica_prenotazione(id_prenotazione):
    db = get_db()
    cursor = db.cursor(dictionary=True)

    if request.method == "POST":
        tipo = request.form["tipo_prenotazione"]
        costo = request.form["costo_prenotazione"]
        data = request.form["data_prenotazione"]
        orario = request.form["orario_prenotazione"]
        fk_utente = request.form["fk_utente"]
        fk_pagamento = request.form["fk_pagamento"]

        query = """
            UPDATE prenotazioni 
            SET tipo_prenotazione=%s, costo_prenotazione=%s, data_prenotazione=%s, 
                orario_prenotazione=%s, fk_utente=%s, fk_pagamento=%s
            WHERE id_prenotazione=%s
        """
        cursor.execute(query, (tipo, costo, data, orario, fk_utente, fk_pagamento, id_prenotazione))
        db.commit()
        
        cursor.close()
        db.close()
        return redirect(url_for('gestione_prenotazioni'))
    
    # 1. Dati della prenotazione attuale
    cursor.execute("SELECT * FROM prenotazioni WHERE id_prenotazione = %s", (id_prenotazione,))
    prenotazione = cursor.fetchone()

    # 2. Lista di tutti gli utenti per la select
    cursor.execute("SELECT id_utente, nome_utente, cognome_utente FROM utenti")
    lista_utenti = cursor.fetchall()

    # 3. Lista di tutti i pagamenti per la select
    cursor.execute("SELECT id_pagamento, metodo_pagamento FROM pagamenti")
    lista_pagamenti = cursor.fetchall()

    cursor.close()
    db.close()
    
    return render_template("modifica_prenotazione.html", prenotazione=prenotazione, utenti=lista_utenti,pagamenti=lista_pagamenti)

#MODIFICA LEZIONE
@app.route("/modifica_lezione/<int:id_lezione>", methods=["GET", "POST"])
def modifica_lezione(id_lezione):
    db = get_db()
    cursor = db.cursor(dictionary=True)

    if request.method == "POST":
        durata = request.form["durata_lezione"]
        data = request.form["data_lezione"]
        aula = request.form["aula_meet"]
        orario = request.form["orario"]
        fk_capitolo = request.form["fk_capitolo"]

        query = """
            UPDATE lezioni 
            SET durata_lezione=%s, data_lezione=%s, aula_meet=%s, orario=%s, fk_capitolo=%s
            WHERE id_lezione=%s
        """
        cursor.execute(query, (durata, data, aula, orario, fk_capitolo, id_lezione))
        db.commit()
        
        cursor.close()
        db.close()
        return redirect(url_for('gestione_lezioni'))
    
    # 1. Dati della lezione
    cursor.execute("SELECT * FROM lezioni WHERE id_lezione = %s", (id_lezione,))
    lezione = cursor.fetchone()

    # 2. Tutti i capitoli con info sulla patente associata (JOIN)
    query_capitoli = """
        SELECT id_capitolo, nome_capitolo, tipologia_patente
        FROM capitoli JOIN patenti 
        ON fk_patente = id_patente
    """
    cursor.execute(query_capitoli)
    capitoli = cursor.fetchall()

    # 3. Elenco patenti per un'eventuale filtro (opzionale)
    cursor.execute("SELECT * FROM patenti")
    patenti = cursor.fetchall()

    cursor.close()
    db.close()

    return render_template("modifica_lezione.html", lezione=lezione,capitoli=capitoli,patenti=patenti)

#ELIMINA UTENTI
@app.route("/elimina_utente/<int:id_utente>")
def elimina_utente(id_utente):

    if not id_utente:
        return redirect(url_for("login"))

    db = get_db()
    cursor = db.cursor(dictionary=True)
    try:
        query = "DELETE FROM utenti WHERE id_utente = %s"
        cursor.execute(query, (id_utente,))
        db.commit()
    except Exception as e:
        print(f"Errore durante l'eliminazione: {e}")
        
    return redirect(url_for('gestione_utenti'))

#ELIMINA PRENOTAZIONE
@app.route("/elimina_prenotazione/<int:id_prenotazione>")
def elimina_prenotazione(id_prenotazione):

    if not id_prenotazione:
        return redirect(url_for("gestione_prenotazioni"))
    
    db = get_db()
    cursor = db.cursor(dictionary=True)
    
    try:
        #cancellazione della prenotazione specifica
        query = "DELETE FROM prenotazioni WHERE id_prenotazione = %s"
        cursor.execute(query, (id_prenotazione,))
        db.commit()
    except Exception as e:
        # In caso di errore (es. vincoli di integrità) stampiamo l'errore
        print(f"Errore durante l'eliminazione della prenotazione: {e}")
    finally:
        cursor.close()
        db.close()
        
    # Reindirizziamo l'utente alla lista delle prenotazioni aggiornata
    return redirect(url_for('gestione_prenotazioni'))

#ELIMINA LEZIONE
@app.route("/elimina_lezione/<int:id_lezione>")
def elimina_lezione(id_lezione):

    if not id_lezione:
        return redirect(url_for('gestione_lezioni'))

    db = get_db()
    cursor = db.cursor()

    try:
        # Eseguiamo la query di eliminazione
        query = "DELETE FROM lezioni WHERE id_lezione = %s"
        cursor.execute(query, (id_lezione,))
        
        # Confermiamo le modifiche al database
        db.commit()
        print(f"Lezione {id_lezione} eliminata con successo.")
        cnx_redis.set("msg",f"Lezione {id_lezione} eliminata con successo.")
        
    except Exception as e:
        print(f"Errore durante l'eliminazione della lezione: {e}")
        cnx_redis.set("msg",f"Errore durante l'eliminazione della lezione.")
        db.rollback()
        
    finally:
        cursor.close()
        db.close()

    # Reindirizziamo l'utente alla pagina di gestione generale
    return redirect(url_for('gestione_lezioni'))

#AGGIUNGI UTENTE
@app.route('/aggiungi_utente', methods=['GET','POST'])
def aggiungi_utente():
    
    if request.method == 'POST':
            nome = request.form['nome']
            cognome = request.form['cognome']
            cf = request.form['cf']
            email = request.form['email']  
            pw_hash = hash_password(request.form['pw'])
            data_nascita = request.form['data_nascita']
            codice_attivazione = request.form['codice']
            data_oggi = datetime.date.today()
            
            if codice_attivazione in ['123', '456']:
                db = get_db()
                cursor = db.cursor(dictionary=True) 
                try:
                    cursor.execute("SELECT id_ruolo FROM ruoli WHERE codice_attivazione = %s", (codice_attivazione,))
                    ris = cursor.fetchone()
                    
                    if ris:
                        fk_ruolo = ris['id_ruolo']
                        query_insert = """
                            INSERT INTO utenti 
                            (nome_utente, cognome_utente, cf, email, password, data_nascita, 
                            stato_account, ultimo_accesso, data_iscrizione, fk_ruolo)
                            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                        """
                        cursor.execute(query_insert, (
                            nome, cognome, cf, email, pw_hash, 
                            data_nascita, "", data_oggi, data_oggi, fk_ruolo
                        ))
                        db.commit()
                except Exception as e:
                    print(f"Errore Inserimento: {e}")
                    db.rollback()
                finally:
                    cursor.close()
            
            return redirect(url_for('gestione_utenti'))

    return render_template("aggiungi_utente.html")

#AGGIUNGI PRENOTAZIONE
@app.route('/aggiungi_prenotazione', methods=['GET', 'POST'])
def aggiungi_prenotazione():
    if request.method == 'POST':
        tipo = request.form['tipo_prenotazione']
        data_p = request.form['data_prenotazione']
        orario_p = request.form['orario_prenotazione']

        # Logica del costo
        listino = {
            "guida": 25,
            "visita oculistica": 65,
            "visita amnestica": 50,
            "esame teorico": 360,
            "esame pratico": 165
        }
        costo = listino.get(tipo, 0)

        db = get_db()
        cursor = db.cursor()
        try:
            query = """
                INSERT INTO prenotazioni (tipo_prenotazione, costo_prenotazione, data_prenotazione, orario_prenotazione)
                VALUES (%s, %s, %s, %s)
            """
            cursor.execute(query, (tipo, costo, data_p, orario_p))
            db.commit()
        except Exception as e:
            print(f"Errore inserimento prenotazione: {e}")
            db.rollback()
        finally:
            cursor.close()
        
        return redirect(url_for('home'))

    return render_template("aggiungi_prenotazione.html")

#INSERIRE LA PATENTE 
@app.route('/aggiungi_patente_utente', methods=['GET', 'POST'])
def aggiungi_patente_utente():
    db = get_db()
    cursor = db.cursor(dictionary=True)

    if request.method == 'POST':
        id_utente = request.form['id_utente']
        id_patente = request.form['id_patente']
        data_conseguimento = request.form['data_conseguimento']

        try:
            # Inserimento nella tabella ute_pat
            query = "INSERT INTO ute_pat (fk_utente, fk_patente, data_conseguimento) VALUES (%s, %s, %s)"
            cursor.execute(query, (id_utente, id_patente, data_conseguimento))
            
            #Aggiorniamo lo stato account per dire che ora ha una patente
            cursor.execute("UPDATE utenti SET stato_account = '' WHERE id_utente = %s", (id_utente,))
            
            db.commit()
        except Exception as e:
            print(f"Errore ute_pat: {e}")
            db.rollback()
        finally:
            cursor.close()
        return redirect(url_for('home'))

    #get
    cursor.execute("SELECT id_utente, nome_utente, cognome_utente, data_nascita FROM utenti WHERE stato_account = '' OR stato_account IS NULL")
    utenti_liberi = cursor.fetchall()

    # 2. Prendo tutte le patenti per poi filtrarle nel template o qui
    cursor.execute("SELECT * FROM patenti")
    tutte_patenti = cursor.fetchall()
    
    cursor.close()
    
    # Calcolo età per ogni utente (utile per il filtro nel template)
    for u in utenti_liberi:
        nascita = u['data_nascita']
        u['eta'] = calcoloEta(nascita)

    return render_template("aggiungi_patente_utente.html", utenti=utenti_liberi, patenti=tutte_patenti)

#AGGIUNGE PRENOTAZIONI
@app.route('/aggiungi_lezione', methods=['GET', 'POST'])
def aggiungi_lezione():
    db = get_db()
    cursor = db.cursor(dictionary=True)

    if request.method == 'POST':
        durata = request.form['durata_lezione']
        data_l = request.form['data_lezione']
        link = request.form['link_meet']
        orario = request.form['orario_lezione']
        id_capitolo = request.form['fk_capitolo']

        try:
            query = """
                INSERT INTO lezioni (durata_lezione, data_lezione, aula_meet, orario, fk_capitolo)
                VALUES (%s, %s, %s, %s, %s)
            """
            cursor.execute(query, (durata, data_l, link, orario, id_capitolo))
            db.commit()
            
        except Exception as e:
            print(f"Errore creazione lezione: {e}")
            db.rollback()
        finally:
            cursor.close()
        
        return redirect(url_for('home'))

    #get
    cursor.execute("SELECT id_capitolo, nome_capitolo, tipologia_patente FROM patenti JOIN capitoli ON id_patente=fk_patente")
    capitoli = cursor.fetchall()
    cursor.close()

    return render_template("aggiungi_lezione.html", capitoli=capitoli)

#AGGIUNGERE QUIZ
@app.route('/aggiungi_quiz', methods=['GET', 'POST'])
def aggiungi_quiz():
    db = get_db()
    cursor = db.cursor(dictionary=True)

    if request.method == 'POST':
        difficolta = request.form['difficolta']
        link = request.form['link_quiz']
        id_capitolo = request.form['fk_capitolo']

        try:
            query = """
                INSERT INTO quiz (difficolta, link_quiz, fk_capitolo)
                VALUES (%s, %s, %s)
            """
            cursor.execute(query, (difficolta, link, id_capitolo))
            db.commit()
            
        except Exception as e:
            print(f"Errore creazione quiz: {e}")
            db.rollback()
        finally:
            cursor.close()
        
        return redirect(url_for('home'))

    #get
    cursor.execute("SELECT id_capitolo, nome_capitolo, tipologia_patente FROM patenti JOIN capitoli ON id_patente=fk_patente")
    capitoli = cursor.fetchall()
    cursor.close()

    return render_template("aggiungi_quiz.html", capitoli=capitoli)
####################################################

#COLLEGAMENTI PAGINE

# PAGINA HOME
@app.route("/")
def home():
    accesso = cnx_redis.get("accesso_eseguito")

    ruolo = None
    if accesso:
        ruolo = get_ruolo(accesso)

    # pulizia messaggi
    cnx_redis.delete("msg")
    cnx_redis.delete("msg_type")

    return render_template("home.html",accesso=accesso,ruolo=ruolo)

# PAGINA LOGIN
@app.route("/login")
def login():
    return render_template("login.html")

# PAGINA ISCRIZIONE
@app.route("/iscriviti")
def iscrizione():
    return render_template("iscriviti.html")

@app.route("/utente")
def pagina_utente():
    id_sessione = cnx_redis.get("accesso_eseguito")
    
    if id_sessione is None:
        return redirect(url_for("login"))
    
    id_utente = int(id_sessione)
    
    #variabili per html
    dati = None
    eta_utente = 0
    lista_patenti = []

    db = get_db()
    cursor = db.cursor(dictionary=True)

    try:
        #recupero dati base utente
        cursor.execute("SELECT * FROM utenti WHERE id_utente=%s", (id_utente,))
        dati = cursor.fetchone()
        
        #se l'utente non esiste nel DB (magari è stato cancellato)
        if dati is None:
            return redirect(url_for("home"))

        # calcolo Età
        if dati['data_nascita']:
            eta_utente = calcoloEta(dati['data_nascita'])
        else:
            eta_utente = 0

        # Recupero le sue patenti con JOIN
        cursor.execute("""
            SELECT p.tipologia_patente 
            FROM patenti p
            JOIN ute_pat up ON p.id_patente = up.fk_patente
            WHERE up.fk_utente = %s
        """, (id_utente,))
        
        patenti_record = cursor.fetchall()
        
        #riempio la lista
        for p in patenti_record:
            lista_patenti.append(p['tipologia_patente'])

    except Exception as e:
        print(f"Errore nel recupero dati utente: {e}")
    finally:
        cursor.close()
        db.close()

    return render_template("pagina_utente.html",accesso=id_utente,dati_utente=dati,eta=eta_utente,patenti=lista_patenti)

# PAGINA PRENOTAZIONI
@app.route('/prenotazione')
def prenotazione():
    id_sessione = cnx_redis.get("accesso_eseguito")
    if id_sessione is None:
        return redirect(url_for("login"))
    
    id_utente = int(id_sessione)

    # Inizializzazione variabili
    stato = ""
    disponibili = []
    patenti = []
    
    db = get_db()
    cursor = db.cursor(dictionary=True)

    try:
        # 1. Recupero Stato Account e Data Nascita in un'unica query
        cursor.execute("SELECT stato_account, data_nascita FROM utenti WHERE id_utente=%s", (id_utente,))
        user_info = cursor.fetchone()
        
        if user_info:
            stato = user_info['stato_account'] if user_info['stato_account'] else ""
            data_nascita = user_info['data_nascita']
        else:
            return redirect(url_for("login"))

        # 2. Se l'utente non è iscritto (stato vuoto), non cerchiamo nemmeno prenotazioni
        if stato != "":
            # Recupero tipologie già prenotate dall'utente
            cursor.execute("SELECT tipo_prenotazione FROM prenotazioni WHERE fk_utente = %s", (id_utente,))
            pren_fatte = [x['tipo_prenotazione'] for x in cursor.fetchall()]

            # 3. Recupero slot liberi filtrati per DATA e ORA direttamente in SQL
            query_slot = """
                SELECT * FROM prenotazioni 
                WHERE fk_utente IS NULL 
                AND fk_pagamento IS NULL
                AND data_prenotazione >= CURDATE()
                AND (data_prenotazione > CURDATE() OR orario_prenotazione >= CURTIME())
                ORDER BY data_prenotazione ASC, orario_prenotazione ASC
            """
            cursor.execute(query_slot)
            tutte_le_prenotazioni = cursor.fetchall()

            # 4. Filtro Logico basato sullo stato
            for p in tutte_le_prenotazioni:
                tipo = p['tipo_prenotazione']
                
                if stato == "teorico":
                    # Può fare visite ed esame teorico solo se non li ha già fatti
                    if tipo in ["visita oculistica", "visita amnestica", "esame teorico"]:
                        if tipo not in pren_fatte:
                            disponibili.append(p)
                
                elif stato == "pratico":
                    # Può fare guide sempre, esame pratico solo una volta
                    if tipo == "guida":
                        disponibili.append(p)
                    elif tipo == "esame pratico":
                        if tipo not in pren_fatte:
                            disponibili.append(p)

        # 5. Gestione PATENTI disponibili per l'età
        eta = calcoloEta(data_nascita)
        cursor.execute("""
            SELECT * FROM patenti 
            WHERE id_patente NOT IN (
                SELECT fk_patente FROM ute_pat WHERE fk_utente = %s
            )
            AND eta_minima <= %s
        """, (id_utente, eta))
        patenti = cursor.fetchall()

    except Exception as e:
        print(f"Errore nella pagina prenotazioni: {e}")
        disponibili = []
        patenti = []

    finally:
        cursor.close()

    return render_template("prenotazione.html",dati_prenotazione=disponibili,dati_patenti=patenti,stato=stato,accesso=id_utente)

# PAGINA CHI SIAMO
@app.route("/chisiamo")
def chisiamo():
    return render_template("chisiamo.html",accesso=cnx_redis.get("accesso_eseguito"))

#PAGINA PATENTI
@app.route("/scelta_patente")
def scelta_patente():
    id_sessione = cnx_redis.get("accesso_eseguito")
    if id_sessione is None:
        return redirect(url_for("login"))
    
    id_utente = int(id_sessione)
    dati_pat = [] 

    db = get_db()
    cursor = db.cursor(dictionary=True)

    try:
        #recupero data di nascita dell'utente
        cursor.execute("""
            SELECT data_nascita 
            FROM utenti 
            WHERE id_utente = %s
        """, (id_utente,))
        
        utente = cursor.fetchone()
        
        #se l'utente esiste allora procedo
        if utente:
            data_nascita = utente["data_nascita"]
            
            #calcolo l'età (gestendo il caso in cui la data manchi nel DB)
            if data_nascita:
                eta = calcoloEta(data_nascita)
            else:
                eta = 0
            
            #recupero patenti disponibili (non ancora possedute + età minima = ok)
            cursor.execute("""
                SELECT * FROM patenti 
                WHERE id_patente NOT IN (
                    SELECT fk_patente 
                    FROM ute_pat 
                    WHERE fk_utente = %s
                )
                AND eta_minima <= %s
            """, (id_utente, eta))
            
            dati_pat = cursor.fetchall()

    except Exception as e:
        print(f"Errore nel caricamento scelta patente: {e}")
    finally:
        cursor.close()
        db.close()

    return render_template("scelta_patente.html",dati_patenti=dati_pat,accesso=id_utente)

#PAGINA RICEVUTA
@app.route("/ricevuta")
def ricevuta():
    return render_template("ricevuta.html",accesso=cnx_redis.get("accesso_eseguito"))

#PAGINA RICEVUTA
@app.route("/lezioni")
def lezioni():
    return render_template("lezioni.html",accesso=cnx_redis.get("accesso_eseguito"))

#PAGINA QUIZ
@app.route("/quiz")
def quiz():
    return render_template("quiz.html",accesso=cnx_redis.get("accesso_eseguito"))

#PAGINA STATISTICHE
@app.route("/statistiche")
def statistiche():
    return render_template("statistiche.html",accesso=cnx_redis.get("accesso_eseguito"))

#PAGINA VISUALIZZA STATISTICHE
@app.route("/visualizza_statistiche")
def visualizza_statistiche():
    return render_template("visualizza_statistiche.html",accesso=cnx_redis.get("accesso_eseguito"))

if __name__ == '__main__':
    # Inizializziamo prima di far partire il server
    try:
        inizializza_progetto("autoscuola")
        # Connessione Redis (Verifica se è attivo)
        cnx_redis = redis.Redis(host=os.getenv("REDIS_HOST"),port=int(os.getenv("REDIS_PORT")),db=int(os.getenv("REDIS_DB")),decode_responses=True)
        cnx_redis.ping()
        setup_redis(cnx_redis)
        print(">>> Connessione Redis riuscita.")
    except Exception as e:
        print(f"ERRORE CRITICO ALL'AVVIO: {e}")
        exit(1)

    # Avvio Flask
    app.run(host=os.getenv("HOST", "127.0.0.1"),port=int(os.getenv("PORT", 5000)),debug=os.getenv("DEBUG", "False") == "True",ssl_context="adhoc")