/*
SQLyog Community v13.1.9 (64 bit)
MySQL - 10.4.32-MariaDB : Database - autoscuola
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`autoscuola` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `autoscuola`;

/*Table structure for table `capitoli` */

DROP TABLE IF EXISTS `capitoli`;

CREATE TABLE `capitoli` (
  `id_capitolo` int(11) NOT NULL AUTO_INCREMENT,
  `nome_capitolo` varchar(100) NOT NULL,
  `difficolta` varchar(20) DEFAULT NULL,
  `fk_patente` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_capitolo`),
  KEY `fk_patente` (`fk_patente`),
  CONSTRAINT `capitoli_ibfk_1` FOREIGN KEY (`fk_patente`) REFERENCES `patenti` (`id_patente`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=185 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `capitoli` */

insert  into `capitoli`(`id_capitolo`,`nome_capitolo`,`difficolta`,`fk_patente`) values 
(1,'Segnali di pericolo','1',6),
(2,'Segnali di pericolo','1',4),
(3,'Segnali di pericolo','1',3),
(4,'Segnali di pericolo','1',2),
(5,'Segnali di pericolo','1',1),
(6,'Segnali di divieto','1',6),
(7,'Segnali di divieto','1',4),
(8,'Segnali di divieto','1',3),
(9,'Segnali di divieto','1',2),
(10,'Segnali di divieto','1',1),
(11,'Segnali di obbligo','1',6),
(12,'Segnali di obbligo','1',4),
(13,'Segnali di obbligo','1',3),
(14,'Segnali di obbligo','1',2),
(15,'Segnali di obbligo','1',1),
(16,'Segnali di precedenza','2',6),
(17,'Segnali di precedenza','2',4),
(18,'Segnali di precedenza','2',3),
(19,'Segnali di precedenza','2',2),
(20,'Segnali di precedenza','2',1),
(21,'Segnaletica orizzontale','2',6),
(22,'Segnaletica orizzontale','2',4),
(23,'Segnaletica orizzontale','2',3),
(24,'Segnaletica orizzontale','2',2),
(25,'Segnaletica orizzontale','2',1),
(26,'Segnalazioni del traffico','2',6),
(27,'Segnalazioni del traffico','2',4),
(28,'Segnalazioni del traffico','2',3),
(29,'Segnalazioni del traffico','2',2),
(30,'Segnalazioni del traffico','2',1),
(31,'Limiti di velocità','1',6),
(32,'Limiti di velocità','1',4),
(33,'Limiti di velocità','1',3),
(34,'Limiti di velocità','1',2),
(35,'Limiti di velocità','1',1),
(36,'Distanza di sicurezza','2',6),
(37,'Distanza di sicurezza','2',4),
(38,'Distanza di sicurezza','2',3),
(39,'Distanza di sicurezza','2',2),
(40,'Distanza di sicurezza','2',1),
(41,'Norme sulla circolazione','2',6),
(42,'Norme sulla circolazione','2',4),
(43,'Norme sulla circolazione','2',3),
(44,'Norme sulla circolazione','2',2),
(45,'Norme sulla circolazione','2',1),
(46,'Precedenze','3',6),
(47,'Precedenze','3',4),
(48,'Precedenze','3',3),
(49,'Precedenze','3',2),
(50,'Precedenze','3',1),
(51,'Fermata, sosta e arresto','2',6),
(52,'Fermata, sosta e arresto','2',4),
(53,'Fermata, sosta e arresto','2',3),
(54,'Fermata, sosta e arresto','2',2),
(55,'Fermata, sosta e arresto','2',1),
(56,'Sorpasso','3',6),
(57,'Sorpasso','3',4),
(58,'Sorpasso','3',3),
(59,'Sorpasso','3',2),
(60,'Sorpasso','3',1),
(61,'Patenti, documenti e assicurazione','2',6),
(62,'Patenti, documenti e assicurazione','2',4),
(63,'Patenti, documenti e assicurazione','2',3),
(64,'Patenti, documenti e assicurazione','2',2),
(65,'Patenti, documenti e assicurazione','2',1),
(66,'Incidenti stradali e primo soccorso','3',6),
(67,'Incidenti stradali e primo soccorso','3',4),
(68,'Incidenti stradali e primo soccorso','3',3),
(69,'Incidenti stradali e primo soccorso','3',2),
(70,'Incidenti stradali e primo soccorso','3',1),
(71,'Alcol, droga e farmaci','3',6),
(72,'Alcol, droga e farmaci','3',4),
(73,'Alcol, droga e farmaci','3',3),
(74,'Alcol, droga e farmaci','3',2),
(75,'Alcol, droga e farmaci','3',1),
(76,'Elementi del veicolo e sicurezza','3',6),
(77,'Elementi del veicolo e sicurezza','3',4),
(78,'Elementi del veicolo e sicurezza','3',3),
(79,'Elementi del veicolo e sicurezza','3',2),
(80,'Elementi del veicolo e sicurezza','3',1),
(81,'Manutenzione e uso del veicolo','3',6),
(82,'Manutenzione e uso del veicolo','3',4),
(83,'Manutenzione e uso del veicolo','3',3),
(84,'Manutenzione e uso del veicolo','3',2),
(85,'Manutenzione e uso del veicolo','3',1),
(86,'Pneumatici e freni','4',6),
(87,'Pneumatici e freni','4',4),
(88,'Pneumatici e freni','4',3),
(89,'Pneumatici e freni','4',2),
(90,'Pneumatici e freni','4',1),
(91,'Sicurezza attiva e passiva','3',6),
(92,'Sicurezza attiva e passiva','3',4),
(93,'Sicurezza attiva e passiva','3',3),
(94,'Sicurezza attiva e passiva','3',2),
(95,'Sicurezza attiva e passiva','3',1),
(96,'Comportamento verso i pedoni','2',6),
(97,'Comportamento verso i pedoni','2',4),
(98,'Comportamento verso i pedoni','2',3),
(99,'Comportamento verso i pedoni','2',2),
(100,'Comportamento verso i pedoni','2',1),
(101,'Rispetto dell’ambiente','2',6),
(102,'Rispetto dell’ambiente','2',4),
(103,'Rispetto dell’ambiente','2',3),
(104,'Rispetto dell’ambiente','2',2),
(105,'Rispetto dell’ambiente','2',1),
(106,'Uso delle luci','2',6),
(107,'Uso delle luci','2',4),
(108,'Uso delle luci','2',3),
(109,'Uso delle luci','2',2),
(110,'Uso delle luci','2',1),
(111,'Traino e rimorchio','4',6),
(112,'Traino e rimorchio','4',4),
(113,'Traino e rimorchio','4',3),
(114,'Traino e rimorchio','4',2),
(115,'Traino e rimorchio','4',1),
(116,'Pannelli integrativi','3',6),
(117,'Pannelli integrativi','3',4),
(118,'Pannelli integrativi','3',3),
(119,'Pannelli integrativi','3',2),
(120,'Pannelli integrativi','3',1),
(121,'Sistema sanzionatorio','3',6),
(122,'Sistema sanzionatorio','3',4),
(123,'Sistema sanzionatorio','3',3),
(124,'Sistema sanzionatorio','3',2),
(125,'Sistema sanzionatorio','3',1),
(126,'Massa complessiva e carichi','4',8),
(127,'Sagoma limite dei veicoli','4',8),
(128,'Sistemazione e fissaggio del carico','5',8),
(129,'Stabilità del veicolo','5',8),
(130,'Spazi di frenatura veicoli pesanti','5',8),
(131,'Cronotachigrafo analogico e digitale','5',8),
(132,'Tempi di guida e riposo','5',8),
(133,'Limitazioni alla circolazione','4',8),
(134,'Documenti trasporto merci','4',8),
(135,'Responsabilità civile e penale','5',8),
(136,'Complessi veicolari e motrici','5',9),
(137,'Traino rimorchi superiori 3,5t','5',9),
(138,'Stabilità complessi veicolari','5',9),
(139,'Frenatura combinata e continua','5',9),
(140,'Autocarri oltre 3,5 tonnellate','4',10),
(141,'Assi e distribuzione del carico','5',10),
(142,'Sospensioni pneumatiche','4',10),
(143,'Impianto frenante ad aria','5',10),
(144,'Trasporto merci pericolose ADR','5',10),
(145,'Segnalazione carichi sporgenti','4',10),
(146,'Trasporto eccezionale','5',10),
(147,'Autoarticolati e autosnodati','5',11),
(148,'Aggancio e sgancio semirimorchio','5',11),
(149,'Frenatura pneumatica integrale','5',11),
(150,'Stabilità in curva veicoli pesanti','5',11),
(151,'Angoli ciechi mezzi pesanti','5',11),
(152,'Complessi veicolari speciali','5',13),
(153,'Traino rimorchio autobus','5',13),
(154,'Trasporto pubblico di persone','4',14),
(155,'Trasporto scolastico','4',14),
(156,'Normativa trasporto persone','5',14),
(157,'Uso porte automatiche e sicurezza','4',14),
(158,'Sistemi antincendio autobus','5',14),
(159,'Comportamento in caso di emergenza','5',14),
(160,'Autosnodati con rimorchio','5',15),
(161,'Manovre autobus articolati','5',15),
(162,'Frenatura autobus con rimorchio','5',15),
(163,'Macchine agricole operatrici','3',16),
(164,'Circolazione mezzi agricoli','3',16),
(165,'Traino attrezzi agricoli','3',16),
(166,'Sagoma e limiti dimensionali agricoli','3',16),
(167,'Sicurezza mezzi agricoli','4',16),
(168,'Normativa taxi','4',17),
(169,'Servizio NCC','4',17),
(170,'Trasporto pubblico non di linea','4',17),
(171,'Regolamenti comunali servizio pubblico','4',17),
(172,'Responsabilità verso i passeggeri','4',17),
(173,'Guida economica e razionale','5',19),
(174,'Logistica e gestione aziendale','5',19),
(175,'Normativa trasporto internazionale','5',19),
(176,'Sicurezza professionale CQC','5',19),
(177,'Prevenzione incidenti sul lavoro','5',19),
(178,'Primo soccorso professionale','4',19),
(179,'Gestione passeggeri e utenza','5',18),
(180,'Normativa trasporto passeggeri','5',18),
(181,'Sicurezza a bordo autobus','5',18),
(182,'Relazione con utenti e disabili','4',18),
(183,'Guida preventiva e difensiva','5',18),
(184,'Primo soccorso a bordo','4',18);

/*Table structure for table `lezioni` */

DROP TABLE IF EXISTS `lezioni`;

CREATE TABLE `lezioni` (
  `id_lezione` int(11) NOT NULL AUTO_INCREMENT,
  `durata_lezione` int(11) DEFAULT NULL,
  `data_lezione` date DEFAULT NULL,
  `aula_meet` varchar(100) DEFAULT NULL,
  `orario` time DEFAULT NULL,
  `fk_capitolo` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_lezione`),
  KEY `fk_capitolo` (`fk_capitolo`),
  CONSTRAINT `lezioni_ibfk_1` FOREIGN KEY (`fk_capitolo`) REFERENCES `capitoli` (`id_capitolo`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `lezioni` */

insert  into `lezioni`(`id_lezione`,`durata_lezione`,`data_lezione`,`aula_meet`,`orario`,`fk_capitolo`) values 
(4,30,'2026-04-08','https://meet.google.com/ghi-333-ccc','10:00:00',4),
(5,60,'2026-04-09','https://meet.google.com/jkl-444-ddd','09:30:00',5),
(6,45,'2026-04-10','https://meet.google.com/mno-555-eee','16:00:00',6),
(7,120,'2026-04-13','https://meet.google.com/pqr-666-fff','14:00:00',15),
(8,60,'2026-04-14','https://meet.google.com/stu-777-ggg','09:00:00',16),
(9,45,'2026-04-14','https://meet.google.com/stu-777-ggg','10:30:00',17),
(10,90,'2026-04-15','https://meet.google.com/vwx-888-hhh','15:00:00',20),
(11,30,'2026-04-16','https://meet.google.com/yza-999-iii','11:00:00',25),
(12,60,'2026-04-17','https://meet.google.com/bcd-000-jjj','09:00:00',30),
(13,150,'2026-04-20','https://meet.google.com/efe-121-kkk','14:30:00',45),
(14,45,'2026-04-21','https://meet.google.com/ghg-232-lll','09:00:00',50),
(15,45,'2026-04-21','https://meet.google.com/ghg-232-lll','10:00:00',51),
(16,60,'2026-04-22','https://meet.google.com/iji-343-mmm','15:30:00',60),
(17,30,'2026-04-23','https://meet.google.com/klk-454-nnn','11:15:00',65),
(18,90,'2026-04-24','https://meet.google.com/mnm-565-ooo','09:00:00',70),
(19,60,'2026-04-27','https://meet.google.com/opo-676-ppp','10:00:00',90),
(20,120,'2026-04-28','https://meet.google.com/qrq-787-qqq','14:00:00',92),
(21,45,'2026-04-29','https://meet.google.com/sts-898-rrr','09:00:00',95),
(22,60,'2026-04-30','https://meet.google.com/utu-909-sss','16:00:00',100),
(23,90,'2026-05-11','https://meet.google.com/vwv-010-ttt','14:00:00',150),
(24,45,'2026-05-12','https://meet.google.com/xyx-121-uuu','10:30:00',160),
(25,60,'2026-05-13','https://meet.google.com/zyz-232-vvv','11:00:00',170),
(26,120,'2026-05-14','https://meet.google.com/aba-343-www','15:00:00',180),
(27,60,'2026-05-15','https://meet.google.com/cdc-454-xxx','09:00:00',183),
(28,180,'2026-05-15','https://meet.google.com/cdc-454-xxx','14:00:00',184),
(29,90,'2026-04-24','https://meet.google.com/eni-igbd-aho','19:00:00',5),
(30,60,'2026-04-18','https://meet.google.com/eni-igbd-aho','19:00:00',91),
(31,50,'2026-04-26','https://meet.google.com/eni-igbd-aho','19:00:00',121),
(32,30,'2026-04-01','https://127.0.0.1:5001/aggiungi_lezione','12:00:00',5),
(33,30,'2026-05-01','https://127.0.0.1:5001/aggiungi_lezione','12:00:00',25),
(34,34,'2026-03-31','https://127.0.0.1:5001/aggiungi_lezione','12:00:00',5);

/*Table structure for table `pagamenti` */

DROP TABLE IF EXISTS `pagamenti`;

CREATE TABLE `pagamenti` (
  `id_pagamento` int(11) NOT NULL AUTO_INCREMENT,
  `metodo_pagamento` varchar(50) DEFAULT NULL,
  `totale_pagamento` int(11) DEFAULT NULL,
  `stato_pagamento` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_pagamento`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `pagamenti` */

insert  into `pagamenti`(`id_pagamento`,`metodo_pagamento`,`totale_pagamento`,`stato_pagamento`) values 
(1,'contanti',1150,'pagare in sede'),
(2,'contanti',1150,'pagare in sede'),
(3,'contanti',50,'pagare in sede'),
(4,'contanti',160,'pagare in sede'),
(5,'contanti',1150,'da pagare in sede'),
(6,'contanti',65,'da pagare in sede'),
(7,'contanti',1150,'pagare in sede'),
(8,'contanti',65,'pagare in sede'),
(9,'contanti',50,'pagare in sede'),
(10,'contanti',360,'pagare in sede'),
(11,'carta',1150,'pagato'),
(12,'contanti',50,'pagare in sede'),
(13,'carta',65,'pagato'),
(14,'carta',360,'pagato'),
(15,'carta',1150,'pagato'),
(16,'carta',50,'pagato'),
(17,'contanti',65,'pagare in sede'),
(18,'contanti',360,'pagare in sede'),
(19,'contanti',50,'pagare in sede'),
(20,'carta',360,'pagato'),
(21,'contanti',1150,'pagare in sede'),
(22,'contanti',1150,'pagare in sede'),
(23,'contanti',360,'pagare in sede'),
(24,'contanti',65,'pagare in sede'),
(25,'contanti',1150,'pagare in sede'),
(26,'contanti',65,'pagare in sede'),
(27,'contanti',360,'pagare in sede'),
(28,'contanti',50,'pagare in sede'),
(29,'contanti',1150,'pagare in sede');

/*Table structure for table `patenti` */

DROP TABLE IF EXISTS `patenti`;

CREATE TABLE `patenti` (
  `id_patente` int(11) NOT NULL AUTO_INCREMENT,
  `tipologia_patente` varchar(10) DEFAULT NULL,
  `descrizione` varchar(100) DEFAULT NULL,
  `eta_minima` int(11) DEFAULT NULL,
  `costo` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_patente`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `patenti` */

insert  into `patenti`(`id_patente`,`tipologia_patente`,`descrizione`,`eta_minima`,`costo`) values 
(1,'AM','Ciclomotori a 2 o 3 ruote e quadricicli leggeri',14,400),
(2,'A1','Motocicli fino a 125 cc e 11 kW, tricicli fino a 15 kW',16,600),
(3,'A2','Motocicli fino a 35 kW',18,700),
(4,'A','Motocicli senza limiti di potenza',24,800),
(5,'B1','Quadricicli non leggeri',16,700),
(6,'B','Autoveicoli fino a 3,5 t e massimo 9 posti',18,900),
(7,'BE','Autoveicoli cat. B con rimorchio oltre 750 kg',18,600),
(8,'C1','Autocarri tra 3,5 t e 7,5 t',18,1250),
(9,'C1E','Autocarri cat. C1 con rimorchio oltre 750 kg',18,1300),
(10,'C','Autocarri oltre 3,5 t',21,1200),
(11,'CE','Autocarri cat. C con rimorchio oltre 750 kg',21,1350),
(12,'D1','Autobus fino a 16 passeggeri oltre al conducente',21,1400),
(13,'D1E','Autobus cat. D1 con rimorchio oltre 750 kg',21,1350),
(14,'D','Autobus senza limite di passeggeri',24,1300),
(15,'DE','Autobus cat. D con rimorchio oltre 750 kg',24,1370),
(16,'KA','Macchine agricole',16,1200),
(17,'KB','Certificato abilitazione professionale per taxi e NCC',21,1200),
(18,'CQC Person','Carta di Qualificazione del Conducente per trasporto persone',21,1500),
(19,'CQC Merci','Carta di Qualificazione del Conducente per trasporto merci',21,1500);

/*Table structure for table `prenotazioni` */

DROP TABLE IF EXISTS `prenotazioni`;

CREATE TABLE `prenotazioni` (
  `id_prenotazione` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_prenotazione` varchar(50) DEFAULT NULL,
  `costo_prenotazione` int(11) DEFAULT NULL,
  `data_prenotazione` date DEFAULT NULL,
  `orario_prenotazione` time DEFAULT NULL,
  `fk_utente` int(11) DEFAULT NULL,
  `fk_pagamento` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_prenotazione`),
  KEY `fk_utente` (`fk_utente`),
  KEY `fk_pagamento` (`fk_pagamento`),
  CONSTRAINT `prenotazioni_ibfk_1` FOREIGN KEY (`fk_utente`) REFERENCES `utenti` (`id_utente`) ON DELETE CASCADE,
  CONSTRAINT `prenotazioni_ibfk_2` FOREIGN KEY (`fk_pagamento`) REFERENCES `pagamenti` (`id_pagamento`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `prenotazioni` */

insert  into `prenotazioni`(`id_prenotazione`,`tipo_prenotazione`,`costo_prenotazione`,`data_prenotazione`,`orario_prenotazione`,`fk_utente`,`fk_pagamento`) values 
(2,'guida',25,'2026-04-13','09:00:00',NULL,NULL),
(3,'visita anamnestica',50,'2026-04-13','10:30:00',18,NULL),
(5,'esame teorico',360,'2026-04-13','14:30:00',18,NULL),
(6,'guida',25,'2026-04-13','16:00:00',NULL,NULL),
(7,'visita oculistica',65,'2026-04-14','08:30:00',17,NULL),
(8,'guida',25,'2026-04-14','09:30:00',NULL,NULL),
(9,'guida',25,'2026-04-14','10:30:00',NULL,NULL),
(10,'esame pratico',160,'2026-04-14','14:00:00',1,NULL),
(11,'guida',25,'2026-04-14','17:00:00',NULL,NULL),
(12,'visita anamnestica',50,'2026-04-15','09:00:00',18,NULL),
(13,'guida',25,'2026-04-15','10:00:00',NULL,NULL),
(14,'guida',25,'2026-04-15','11:00:00',NULL,NULL),
(15,'esame teorico',360,'2026-04-15','15:00:00',19,14),
(16,'visita oculistica',65,'2026-04-15','17:30:00',18,NULL),
(17,'guida',25,'2026-04-16','08:00:00',NULL,NULL),
(18,'esame pratico',160,'2026-04-16','09:00:00',NULL,NULL),
(19,'guida',25,'2026-04-16','11:30:00',NULL,NULL),
(20,'guida',25,'2026-04-16','14:30:00',NULL,NULL),
(21,'visita anamnestica',50,'2026-04-16','16:00:00',19,NULL),
(22,'guida',25,'2026-04-16','18:00:00',NULL,NULL),
(23,'guida',25,'2026-04-17','08:30:00',NULL,NULL),
(24,'visita oculistica',65,'2026-04-17','10:00:00',19,NULL),
(25,'esame teorico',360,'2026-04-17','11:00:00',17,20),
(26,'guida',25,'2026-04-17','14:00:00',NULL,NULL),
(27,'guida',25,'2026-04-17','15:00:00',NULL,NULL),
(28,'esame pratico',160,'2026-04-17','16:30:00',NULL,NULL),
(29,'guida',25,'2026-04-18','09:00:00',NULL,NULL),
(30,'guida',25,'2026-04-18','10:00:00',NULL,NULL),
(31,'visita anamnestica',50,'2026-04-20','08:30:00',20,16),
(32,'guida',25,'2026-04-20','09:30:00',NULL,NULL),
(33,'visita oculistica',65,'2026-04-20','11:00:00',20,17),
(34,'guida',25,'2026-04-20','15:00:00',NULL,NULL),
(36,'guida',25,'2026-04-21','11:00:00',NULL,NULL),
(37,'guida',25,'2026-04-21','12:00:00',NULL,NULL),
(38,'esame pratico',160,'2026-04-21','14:30:00',NULL,NULL),
(39,'guida',25,'2026-04-21','16:30:00',NULL,NULL),
(40,'visita anamnestica',50,'2026-04-22','10:00:00',17,19),
(41,'guida',25,'2026-04-22','11:00:00',NULL,NULL),
(43,'guida',25,'2026-04-22','17:00:00',NULL,NULL),
(45,'guida',25,'2026-04-23','10:30:00',NULL,NULL),
(46,'esame pratico',160,'2026-04-23','14:00:00',NULL,NULL),
(47,'guida',25,'2026-04-23','16:00:00',NULL,NULL),
(48,'guida',25,'2026-04-24','09:00:00',NULL,NULL),
(50,'guida',25,'2026-04-24','14:30:00',NULL,NULL),
(51,'guida',25,'2026-04-23','16:30:00',NULL,NULL),
(52,'esame pratico',165,'2026-04-29','13:00:00',NULL,NULL),
(53,'esame pratico',165,'2026-04-30','13:00:00',NULL,NULL),
(54,'visita oculistica',65,'2026-04-26','16:00:00',NULL,NULL),
(57,'visita anamnestica',50,'2026-04-20','08:30:00',NULL,NULL),
(58,'visita oculistica',65,'2026-04-20','11:00:00',NULL,NULL),
(59,'visita oculistica',65,'2026-04-02','11:00:00',NULL,NULL),
(60,'esame teorico',360,'2026-04-21','09:00:00',NULL,NULL),
(61,'visita amnestica',50,'2026-05-01','12:00:00',NULL,NULL);

/*Table structure for table `quiz` */

DROP TABLE IF EXISTS `quiz`;

CREATE TABLE `quiz` (
  `id_quiz` int(11) NOT NULL AUTO_INCREMENT,
  `difficolta` varchar(20) DEFAULT NULL,
  `link_quiz` varchar(255) DEFAULT NULL,
  `fk_capitolo` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_quiz`),
  KEY `fk_capitolo` (`fk_capitolo`),
  CONSTRAINT `quiz_ibfk_1` FOREIGN KEY (`fk_capitolo`) REFERENCES `capitoli` (`id_capitolo`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `quiz` */

insert  into `quiz`(`id_quiz`,`difficolta`,`link_quiz`,`fk_capitolo`) values 
(3,'1','https://www.quizpatenteapp.com/quiz-ministeriali/s',6),
(4,'1','https://www.quizpatenteapp.com/quiz-ministeriali/s',4),
(5,'1','https://www.quizpatenteapp.com/quiz-ministeriali/s',3),
(6,'1','https://www.quizpatenteapp.com/quiz-ministeriali/s',2),
(7,'1','https://www.quizpatenteapp.com/quiz-ministeriali/s',1),
(8,'1','https://www.quizpatenteapp.com/quiz-ministeriali/s',6),
(9,'1','https://www.quizpatenteapp.com/quiz-ministeriali/s',4),
(10,'1','https://www.quizpatenteapp.com/quiz-ministeriali/s',3),
(11,'1','https://www.quizpatenteapp.com/quiz-ministeriali/s',2),
(12,'1','https://www.quizpatenteapp.com/quiz-ministeriali/s',1),
(13,'1','https://www.quizpatenteapp.com/quiz-ministeriali/s',6),
(14,'1','https://www.quizpatenteapp.com/quiz-ministeriali/s',4),
(15,'1','https://www.quizpatenteapp.com/quiz-ministeriali/s',3),
(16,'1','https://www.quizpatenteapp.com/quiz-ministeriali/s',2),
(17,'1','https://www.quizpatenteapp.com/quiz-ministeriali/s',1),
(18,'2','https://www.quizpatenteapp.com/quiz-ministeriali/s',6),
(19,'2','https://www.quizpatenteapp.com/quiz-ministeriali/s',4),
(20,'2','https://www.quizpatenteapp.com/quiz-ministeriali/s',3),
(21,'2','https://www.quizpatenteapp.com/quiz-ministeriali/s',2),
(22,'2','https://www.quizpatenteapp.com/quiz-ministeriali/s',1),
(23,'2','https://www.quizpatenteapp.com/quiz-ministeriali/s',6),
(24,'2','https://www.quizpatenteapp.com/quiz-ministeriali/s',4),
(25,'2','https://www.quizpatenteapp.com/quiz-ministeriali/s',3),
(26,'2','https://www.quizpatenteapp.com/quiz-ministeriali/s',2),
(27,'2','https://www.quizpatenteapp.com/quiz-ministeriali/s',1),
(28,'2','https://www.quizpatenteapp.com/quiz-ministeriali/s',6),
(29,'2','https://www.quizpatenteapp.com/quiz-ministeriali/s',4),
(30,'2','https://www.quizpatenteapp.com/quiz-ministeriali/s',3),
(31,'2','https://www.quizpatenteapp.com/quiz-ministeriali/s',2),
(32,'2','https://www.quizpatenteapp.com/quiz-ministeriali/s',1),
(33,'1','https://www.quizpatenteapp.com/quiz-ministeriali/l',6),
(34,'1','https://www.quizpatenteapp.com/quiz-ministeriali/l',4),
(35,'1','https://www.quizpatenteapp.com/quiz-ministeriali/l',3),
(36,'1','https://www.quizpatenteapp.com/quiz-ministeriali/l',2),
(37,'1','https://www.quizpatenteapp.com/quiz-ministeriali/l',1),
(38,'2','https://www.quizpatenteapp.com/quiz-ministeriali/d',6),
(39,'2','https://www.quizpatenteapp.com/quiz-ministeriali/d',4),
(40,'2','https://www.quizpatenteapp.com/quiz-ministeriali/d',3),
(41,'2','https://www.quizpatenteapp.com/quiz-ministeriali/d',2),
(42,'2','https://www.quizpatenteapp.com/quiz-ministeriali/d',1),
(43,'2','https://www.quizpatenteapp.com/quiz-ministeriali/n',6),
(44,'2','https://www.quizpatenteapp.com/quiz-ministeriali/n',4),
(45,'2','https://www.quizpatenteapp.com/quiz-ministeriali/n',3),
(46,'2','https://www.quizpatenteapp.com/quiz-ministeriali/n',2),
(47,'2','https://www.quizpatenteapp.com/quiz-ministeriali/n',1),
(48,'3','https://www.quizpatenteapp.com/quiz-ministeriali/p',6),
(49,'3','https://www.quizpatenteapp.com/quiz-ministeriali/p',4),
(50,'3','https://www.quizpatenteapp.com/quiz-ministeriali/p',3),
(51,'3','https://www.quizpatenteapp.com/quiz-ministeriali/p',2),
(52,'3','https://www.quizpatenteapp.com/quiz-ministeriali/p',1),
(53,'2','https://www.quizpatenteapp.com/quiz-ministeriali/f',6),
(54,'2','https://www.quizpatenteapp.com/quiz-ministeriali/f',4),
(55,'2','https://www.quizpatenteapp.com/quiz-ministeriali/f',3),
(56,'2','https://www.quizpatenteapp.com/quiz-ministeriali/f',2),
(57,'2','https://www.quizpatenteapp.com/quiz-ministeriali/f',1),
(58,'3','https://www.quizpatenteapp.com/quiz-ministeriali/s',6),
(59,'3','https://www.quizpatenteapp.com/quiz-ministeriali/s',4),
(60,'3','https://www.quizpatenteapp.com/quiz-ministeriali/s',3),
(61,'3','https://www.quizpatenteapp.com/quiz-ministeriali/s',2),
(62,'3','https://www.quizpatenteapp.com/quiz-ministeriali/s',1),
(63,'2','https://www.quizpatenteapp.com/quiz-ministeriali/p',6),
(64,'2','https://www.quizpatenteapp.com/quiz-ministeriali/p',4),
(65,'2','https://www.quizpatenteapp.com/quiz-ministeriali/p',3),
(66,'2','https://www.quizpatenteapp.com/quiz-ministeriali/p',2),
(67,'2','https://www.quizpatenteapp.com/quiz-ministeriali/p',1),
(68,'3','https://www.quizpatenteapp.com/quiz-ministeriali/i',6),
(69,'3','https://www.quizpatenteapp.com/quiz-ministeriali/i',4),
(70,'3','https://www.quizpatenteapp.com/quiz-ministeriali/i',3),
(71,'3','https://www.quizpatenteapp.com/quiz-ministeriali/i',2),
(72,'3','https://www.quizpatenteapp.com/quiz-ministeriali/i',1),
(73,'3','https://www.quizpatenteapp.com/quiz-ministeriali/a',6),
(74,'3','https://www.quizpatenteapp.com/quiz-ministeriali/a',4),
(75,'3','https://www.quizpatenteapp.com/quiz-ministeriali/a',3),
(76,'3','https://www.quizpatenteapp.com/quiz-ministeriali/a',2),
(77,'3','https://www.quizpatenteapp.com/quiz-ministeriali/a',1),
(78,'3','https://www.quizpatenteapp.com/quiz-ministeriali/e',6),
(79,'3','https://www.quizpatenteapp.com/quiz-ministeriali/e',4),
(80,'3','https://www.quizpatenteapp.com/quiz-ministeriali/e',3),
(81,'3','https://www.quizpatenteapp.com/quiz-ministeriali/e',2),
(82,'3','https://www.quizpatenteapp.com/quiz-ministeriali/e',1),
(83,'3','https://www.quizpatenteapp.com/quiz-ministeriali/m',6),
(84,'3','https://www.quizpatenteapp.com/quiz-ministeriali/m',4),
(85,'3','https://www.quizpatenteapp.com/quiz-ministeriali/m',3),
(86,'3','https://www.quizpatenteapp.com/quiz-ministeriali/m',2),
(87,'3','https://www.quizpatenteapp.com/quiz-ministeriali/m',1),
(88,'4','https://www.quizpatenteapp.com/quiz-ministeriali/p',6),
(89,'4','https://www.quizpatenteapp.com/quiz-ministeriali/p',4),
(90,'4','https://www.quizpatenteapp.com/quiz-ministeriali/p',3),
(91,'4','https://www.quizpatenteapp.com/quiz-ministeriali/p',2),
(92,'4','https://www.quizpatenteapp.com/quiz-ministeriali/p',1),
(93,'3','https://www.quizpatenteapp.com/quiz-ministeriali/s',6),
(94,'3','https://www.quizpatenteapp.com/quiz-ministeriali/s',4),
(95,'3','https://www.quizpatenteapp.com/quiz-ministeriali/s',3),
(96,'3','https://www.quizpatenteapp.com/quiz-ministeriali/s',2),
(97,'3','https://www.quizpatenteapp.com/quiz-ministeriali/s',1),
(98,'2','https://www.quizpatenteapp.com/quiz-ministeriali/c',6),
(99,'2','https://www.quizpatenteapp.com/quiz-ministeriali/c',4),
(100,'2','https://www.quizpatenteapp.com/quiz-ministeriali/c',3),
(101,'2','https://www.quizpatenteapp.com/quiz-ministeriali/c',2),
(102,'2','https://www.quizpatenteapp.com/quiz-ministeriali/c',1),
(103,'2','https://www.quizpatenteapp.com/quiz-ministeriali/r',6),
(104,'2','https://www.quizpatenteapp.com/quiz-ministeriali/r',4),
(105,'2','https://www.quizpatenteapp.com/quiz-ministeriali/r',3),
(106,'2','https://www.quizpatenteapp.com/quiz-ministeriali/r',2),
(107,'2','https://www.quizpatenteapp.com/quiz-ministeriali/r',1),
(108,'2','https://www.quizpatenteapp.com/quiz-ministeriali/u',6),
(109,'2','https://www.quizpatenteapp.com/quiz-ministeriali/u',4),
(110,'2','https://www.quizpatenteapp.com/quiz-ministeriali/u',3),
(111,'2','https://www.quizpatenteapp.com/quiz-ministeriali/u',2),
(112,'2','https://www.quizpatenteapp.com/quiz-ministeriali/u',1),
(113,'4','https://www.quizpatenteapp.com/quiz-ministeriali/t',6),
(114,'4','https://www.quizpatenteapp.com/quiz-ministeriali/t',4),
(115,'4','https://www.quizpatenteapp.com/quiz-ministeriali/t',3),
(116,'4','https://www.quizpatenteapp.com/quiz-ministeriali/t',2),
(117,'4','https://www.quizpatenteapp.com/quiz-ministeriali/t',1),
(118,'3','https://www.quizpatenteapp.com/quiz-ministeriali/p',6),
(119,'3','https://www.quizpatenteapp.com/quiz-ministeriali/p',4),
(120,'3','https://www.quizpatenteapp.com/quiz-ministeriali/p',3),
(121,'3','https://www.quizpatenteapp.com/quiz-ministeriali/p',2),
(122,'3','https://www.quizpatenteapp.com/quiz-ministeriali/p',1),
(123,'3','https://www.quizpatenteapp.com/quiz-ministeriali/s',6),
(124,'3','https://www.quizpatenteapp.com/quiz-ministeriali/s',4),
(125,'3','https://www.quizpatenteapp.com/quiz-ministeriali/s',3),
(126,'3','https://www.quizpatenteapp.com/quiz-ministeriali/s',2),
(127,'3','https://www.quizpatenteapp.com/quiz-ministeriali/s',1),
(128,'3','https://www.quizpatenteapp.com/quiz-ministeriali/s',101);

/*Table structure for table `ruoli` */

DROP TABLE IF EXISTS `ruoli`;

CREATE TABLE `ruoli` (
  `id_ruolo` int(11) NOT NULL AUTO_INCREMENT,
  `nome_ruolo` varchar(50) NOT NULL,
  `codice_attivazione` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_ruolo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `ruoli` */

insert  into `ruoli`(`id_ruolo`,`nome_ruolo`,`codice_attivazione`) values 
(1,'Studente','123'),
(2,'Istruttore','456');

/*Table structure for table `ute_pat` */

DROP TABLE IF EXISTS `ute_pat`;

CREATE TABLE `ute_pat` (
  `id_ute_pat` int(11) NOT NULL AUTO_INCREMENT,
  `data_conseguimento` date DEFAULT NULL,
  `data_scadenza` date DEFAULT NULL,
  `fk_utente` int(11) DEFAULT NULL,
  `fk_patente` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_ute_pat`),
  KEY `fk_utente` (`fk_utente`),
  KEY `fk_patente` (`fk_patente`),
  CONSTRAINT `ute_pat_ibfk_1` FOREIGN KEY (`fk_utente`) REFERENCES `utenti` (`id_utente`) ON DELETE CASCADE,
  CONSTRAINT `ute_pat_ibfk_2` FOREIGN KEY (`fk_patente`) REFERENCES `patenti` (`id_patente`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `ute_pat` */

insert  into `ute_pat`(`id_ute_pat`,`data_conseguimento`,`data_scadenza`,`fk_utente`,`fk_patente`) values 
(1,NULL,NULL,1,6),
(2,NULL,NULL,16,6),
(3,NULL,NULL,17,6),
(4,NULL,NULL,18,6),
(5,NULL,NULL,19,6),
(6,NULL,NULL,20,6),
(7,'2026-04-01',NULL,20,8),
(8,'2026-03-31',NULL,20,1),
(9,'2026-04-07',NULL,17,3),
(10,'2026-04-02',NULL,9,6),
(11,'2026-04-01',NULL,24,6),
(14,NULL,NULL,25,6),
(15,NULL,NULL,27,6),
(16,'2022-05-10',NULL,27,1),
(17,'2026-04-12',NULL,28,1),
(18,'2026-04-12',NULL,28,1);

/*Table structure for table `utenti` */

DROP TABLE IF EXISTS `utenti`;

CREATE TABLE `utenti` (
  `id_utente` int(11) NOT NULL AUTO_INCREMENT,
  `nome_utente` varchar(50) NOT NULL,
  `cognome_utente` varchar(50) NOT NULL,
  `cf` char(16) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `data_nascita` date DEFAULT NULL,
  `stato_account` varchar(20) DEFAULT NULL,
  `ultimo_accesso` date DEFAULT NULL,
  `data_iscrizione` date DEFAULT NULL,
  `fk_ruolo` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_utente`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `codice_fiscale` (`cf`),
  KEY `fk_ruolo` (`fk_ruolo`),
  CONSTRAINT `utenti_ibfk_1` FOREIGN KEY (`fk_ruolo`) REFERENCES `ruoli` (`id_ruolo`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `utenti` */

insert  into `utenti`(`id_utente`,`nome_utente`,`cognome_utente`,`cf`,`email`,`password`,`data_nascita`,`stato_account`,`ultimo_accesso`,`data_iscrizione`,`fk_ruolo`) values 
(1,'Filippo','Badali','BDLFPP07C14B898X','badofilocr@gmail.com','b133a0c0e9bee3be20163d2ad31d6248db292aa6dcb1ee087a2aa50e0fc75ae2','2007-03-14','teorico','2026-04-12','2026-03-01',2),
(3,'diddio','g45','erfr','ef','0766fa0a0cd628539962','2026-03-29','teorico','2026-03-01','2026-03-01',1),
(6,'mattia','badali','BDLMTT03C03B898M','mattia@gmail.com','b133a0c0e9bee3be20163d2ad31d6248db292aa6dcb1ee087a2aa50e0fc75ae2','2026-03-08','teorico','2026-03-03','2026-03-03',1),
(7,'bbq','bacon','bgtr','bherfrre@rfiir.com','b133a0c0e9bee3be20163d2ad31d6248db292aa6dcb1ee087a2aa50e0fc75ae2','2026-02-26','teorico','2026-03-03','2026-03-03',1),
(8,'diddio','zebby','tg','eedde@ifù.com','b133a0c0e9bee3be20163d2ad31d6248db292aa6dcb1ee087a2aa50e0fc75ae2','2026-03-05','teorico','2026-03-03','2026-03-03',1),
(9,'pinco','pallino','e','mttia@gmail.com','b133a0c0e9bee3be20163d2ad31d6248db292aa6dcb1ee087a2aa50e0fc75ae2','2026-03-05','Patentato','2026-03-03','2026-03-03',1),
(10,'kalulu','balulu','f','refee@gmail.com','scrypt:32768:8:1$j8bE3DGaBLWKfRpO$0b5c5ed11ce4a450ec5140347537acc8e59b13b1ce28504368d2cb35209fa77d86eb992681b2c9fd698c5703c34fe9a60e7c29dc07cc8724dc34d7a58266ed01','2026-03-11','teorico','2026-03-11','2026-03-11',1),
(11,'pippo','baduz','m','badofiocr@gmail.com','scrypt:32768:8:1$J64FXsACOOMcfoGK$578cd7039c90eb25824a4e04e983aaea08022e9db571fbe1d7c07b3b773f304587b2744d5ace2554d69d5d4ddcb38dd97eb398453201dff20a7946ee3f01057c','2026-03-06','teorico','2026-03-11','2026-03-11',1),
(12,'ninre','rffre','ede','rfe@gmail.com','scrypt:32768:8:1$afvjooXpaE5tVBfc$e77a4ea6f66e74595c96e54a7c20a2308535774c42e7715382e171a77ac84b0c9845f5b6b9d3f90296ddbc4d8a8c1f0ea5e30ceff5b47df64bb885bae13c3a04','2026-02-25','teorico','2026-03-12','2026-03-12',1),
(13,'eomejoie','eddee','eededq','ewdjoie@gmail.com','scrypt:32768:8:1$bxtAb4gFUycJ14Ax$717a5dfdfadbb1df122d082af103b46b9b755e8c3278ca592d726a52ebefa5dab68f3a72d68b9b610a16dab83317b412a1d14528387a9c42dc227642fb6dee43','2026-03-03','teorico','2026-03-12','2026-03-12',1),
(14,'ehgtrtgr','ergrrg','rreer','cbadu@gjiri.vom','scrypt:32768:8:1$PE16qPXopT7MnkHo$664340fab73b4d64c2ffc50e5db03c356178d198685f688eed4fc88e55dbbed1248ca4dc203e419dbf4572772e818b99cd3c27ed58058103f8a2ee21cc5a3bb7','2026-02-27','teorico','2026-03-12','2026-03-12',1),
(15,'erdqe','ewdewd','wdede','niewjide@gmail.com','scrypt:32768:8:1$2WrDg02J0is4tuOl$1be98ece0b26445f18d422d9fbcfc4840403d7e106a6346c2ca9cb3c012934bc2046a1b6d27c8d4114f7b2466b1f4a981f6ec84821e214f15920acb6c7f9174e','2026-03-03','teorico','2026-03-12','2026-03-12',1),
(16,'prova1','prova1','8','prova1@gmail.com','b133a0c0e9bee3be20163d2ad31d6248db292aa6dcb1ee087a2aa50e0fc75ae2','2007-02-02','teorico','2026-04-02','2026-04-02',1),
(17,'prova2','prova2','k','prova2@gmail.com','b133a0c0e9bee3be20163d2ad31d6248db292aa6dcb1ee087a2aa50e0fc75ae2','2008-01-05','teorico','2026-04-12','2026-04-05',1),
(18,'prova3','prova3','w','prova3@gmail.com','b133a0c0e9bee3be20163d2ad31d6248db292aa6dcb1ee087a2aa50e0fc75ae2','2006-01-05','teorico','2026-04-12','2026-04-05',1),
(19,'prova4','prova4','q','prova4@gmail.com','b133a0c0e9bee3be20163d2ad31d6248db292aa6dcb1ee087a2aa50e0fc75ae2','2005-06-05','teorico','2026-04-05','2026-04-05',1),
(20,'prova5','prova5','1','prova5@gmail.com','b133a0c0e9bee3be20163d2ad31d6248db292aa6dcb1ee087a2aa50e0fc75ae2','2006-01-05','teorico','2026-04-10','2026-04-05',1),
(21,'prova6','prova6','2','prova6@gmail.com','b133a0c0e9bee3be20163d2ad31d6248db292aa6dcb1ee087a2aa50e0fc75ae2','2004-05-06','','2026-04-06','2026-04-06',1),
(24,'pluto','paperino','1235689543','edw9jedj9e@efijedjid','b133a0c0e9bee3be20163d2ad31d6248db292aa6dcb1ee087a2aa50e0fc75ae2','2026-04-09','','2026-04-10','2026-04-10',1),
(25,'giacomo','bianchi','BNCGCM05H06B898X','giacomo.bianchi@gmail.com','b133a0c0e9bee3be20163d2ad31d6248db292aa6dcb1ee087a2aa50e0fc75ae2','2005-06-06','teorico','2026-04-10','2026-04-10',1),
(27,'nello','Tornincasa','3456789','nello@gmail.com','b133a0c0e9bee3be20163d2ad31d6248db292aa6dcb1ee087a2aa50e0fc75ae2','2007-01-01','teorico','2026-04-10','2026-04-10',1),
(28,'provadefinitiva','.','8900','provadef@gmail.com','b133a0c0e9bee3be20163d2ad31d6248db292aa6dcb1ee087a2aa50e0fc75ae2','2012-01-01','','2026-04-12','2026-04-12',1),
(30,'istruttore','prova','12345678iuytrfds','istruttore@gmail.com','b133a0c0e9bee3be20163d2ad31d6248db292aa6dcb1ee087a2aa50e0fc75ae2','1992-03-05','','2026-04-12','2026-04-12',2);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
